{ ============================================================
  rss_log.pas — Logging fuer TC Log-Fenster und Datei
  ============================================================ }
unit rss_log;

{$MODE ObjFPC}{$H+}

interface

uses
  Windows, SysUtils, fsplugin;

procedure LogInit(const LogDir: UnicodeString);
procedure LogMsg(const Msg: UnicodeString);
procedure LogError(const Msg: UnicodeString);
procedure LogDetail(const Msg: UnicodeString);
procedure LogToTC(MsgType: Integer; const Msg: UnicodeString);

implementation

var
  GLogFile: UnicodeString;
  GLogEnabled: Boolean;

procedure LogInit(const LogDir: UnicodeString);
begin
  GLogFile := IncludeTrailingPathDelimiter(LogDir) + 'wfx_rss.log';
  GLogEnabled := False;
end;

procedure WriteToFile(const Line: UnicodeString);
var
  F: TextFile;
  AnsiLine: AnsiString;
begin
  if not GLogEnabled then
    Exit;
  AnsiLine := UTF8Encode(Line);
  try
    AssignFile(F, UTF8Encode(GLogFile));
    if FileExists(UTF8Encode(GLogFile)) then
      Append(F)
    else
      Rewrite(F);
    WriteLn(F, FormatDateTime('yyyy-mm-dd hh:nn:ss', Now), ' ', AnsiLine);
    CloseFile(F);
  except
  end;
end;

procedure LogToTC(MsgType: Integer; const Msg: UnicodeString);
var
  AnsiMsg: AnsiString;
begin
  AnsiMsg := UTF8Encode(Msg);
  if Assigned(GLogCb) then
  begin
    try
      GLogCb(GPluginNr, MsgType, PAnsiChar(AnsiMsg));
    except
    end;
  end;
end;

procedure LogMsg(const Msg: UnicodeString);
begin
  if not GLogEnabled then Exit;
  WriteToFile('[INFO] ' + Msg);
  LogToTC(msgtype_details, 'RSS: ' + Msg);
end;

procedure LogError(const Msg: UnicodeString);
begin
  if not GLogEnabled then Exit;
  WriteToFile('[ERROR] ' + Msg);
  LogToTC(msgtype_importanterror, 'RSS Error: ' + Msg);
end;

procedure LogDetail(const Msg: UnicodeString);
begin
  if not GLogEnabled then Exit;
  WriteToFile('[DETAIL] ' + Msg);
end;

end.
