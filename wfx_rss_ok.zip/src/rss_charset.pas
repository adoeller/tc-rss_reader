{ ============================================================
  rss_charset.pas — Encoding detection and normalization.

  Detection cascade (first match wins):
    1. BOM         (deterministic)
    2. HTTP Content-Type charset
    3. XML declaration encoding
    4. Full UTF-8 validation
    5. Byte-pattern analysis + <language> tag heuristic
    6. Fallback: Windows-1252

  NormalizeToUtf8 converts any detected encoding to UTF-8
  via Windows MultiByteToWideChar / WideCharToMultiByte.
  ============================================================ }
unit rss_charset;

{$MODE ObjFPC}{$H+}

interface

uses
  Windows, SysUtils;

{ Returns Windows codepage (65001=UTF-8, 1251=Win-1251, 932=Shift-JIS, ...) }
function DetectEncoding(const Body: AnsiString;
  const ContentType: AnsiString): DWORD;

{ Convert Body from given codepage directly to UnicodeString
  via MultiByteToWideChar — no FPC UTF8Decode involved. }
function BodyToUnicode(const Body: AnsiString; CP: DWORD): UnicodeString;

{ Convert Body from given codepage to UTF-8 AnsiString }
function NormalizeToUtf8(const Body: AnsiString;
  CP: DWORD): AnsiString;

{ Exposed for testing }
function IsValidUtf8(const Body: AnsiString): Boolean;
function EncodingNameToCodepage(const Name: AnsiString): DWORD;
function ExtractXmlEncoding(const Body: AnsiString): AnsiString;
function ExtractContentTypeCharset(const CT: AnsiString): AnsiString;
function ExtractLanguageTag(const Body: AnsiString): AnsiString;

implementation

const
  CP_UTF8    = 65001;
  CP_UTF16LE = 1200;
  CP_UTF16BE = 1201;

{ ============================================================
  BOM detection
  ============================================================ }
function DetectBOM(const Body: AnsiString): DWORD;
var
  Len: Integer;
  B0, B1, B2: Byte;
begin
  Result := 0;
  Len := Length(Body);
  if Len < 2 then Exit;
  B0 := Byte(Body[1]);
  B1 := Byte(Body[2]);
  if Len >= 3 then B2 := Byte(Body[3]) else B2 := 0;
  if (B0 = $EF) and (B1 = $BB) and (B2 = $BF) then
    Result := CP_UTF8
  else if (B0 = $FF) and (B1 = $FE) then
    Result := CP_UTF16LE
  else if (B0 = $FE) and (B1 = $FF) then
    Result := CP_UTF16BE;
end;

{ ============================================================
  Full UTF-8 validation — scans entire body, no sampling.
  A single invalid byte causes False.
  ============================================================ }
function IsValidUtf8(const Body: AnsiString): Boolean;
var
  I, Len, SeqLen, J: Integer;
  B, Cont: Byte;
begin
  Result := False;
  Len := Length(Body);
  I := 1;
  while I <= Len do
  begin
    B := Byte(Body[I]);

    if B < $80 then
    begin
      Inc(I);
      Continue;
    end;

    { Determine expected sequence length }
    if (B and $E0) = $C0 then SeqLen := 2
    else if (B and $F0) = $E0 then SeqLen := 3
    else if (B and $F8) = $F0 then SeqLen := 4
    else Exit;  { 0x80-0xBF bare, or 0xF8-0xFF: invalid }

    { Reject overlong 2-byte encodings (0xC0/0xC1) }
    if (SeqLen = 2) and (B < $C2) then Exit;

    { Validate continuation bytes }
    for J := 1 to SeqLen - 1 do
    begin
      if I + J > Len then Exit;
      Cont := Byte(Body[I + J]);
      if (Cont and $C0) <> $80 then Exit;
    end;

    Inc(I, SeqLen);
  end;
  Result := True;
end;

{ ============================================================
  Extract charset from HTTP Content-Type header
  e.g. "text/xml; charset=windows-1251"
  ============================================================ }
function ExtractContentTypeCharset(const CT: AnsiString): AnsiString;
var
  S: AnsiString;
  P, P2: Integer;
begin
  Result := '';
  S := LowerCase(CT);
  P := Pos('charset=', S);
  if P = 0 then Exit;
  Inc(P, 8);
  if P > Length(S) then Exit;
  if S[P] = '"' then Inc(P);
  P2 := P;
  while P2 <= Length(S) do
  begin
    if S[P2] in [';', ' ', '"', #13, #10] then Break;
    Inc(P2);
  end;
  Result := Copy(S, P, P2 - P);
end;

{ ============================================================
  Extract encoding from XML declaration (first 1024 bytes)
  e.g. <?xml version="1.0" encoding="windows-1251"?>
  ============================================================ }
function ExtractXmlEncoding(const Body: AnsiString): AnsiString;
var
  Sample, SL: AnsiString;
  P, P2, Start: Integer;
  Quote: AnsiChar;
begin
  Result := '';
  if Length(Body) > 1024 then
    Sample := Copy(Body, 1, 1024)
  else
    Sample := Body;
  SL := LowerCase(Sample);
  { skip BOM if present }
  Start := 1;
  if (Length(Sample) >= 3) and
     (Byte(Sample[1]) = $EF) and (Byte(Sample[2]) = $BB) and
     (Byte(Sample[3]) = $BF) then
    Start := 4;

  P := Pos('encoding=', SL);
  if (P = 0) or (P < Start) then Exit;
  Inc(P, 9);
  if P > Length(Sample) then Exit;
  Quote := Sample[P];
  if (Quote <> '"') and (Quote <> '''') then Exit;
  Inc(P);
  P2 := P;
  while P2 <= Length(Sample) do
  begin
    if Sample[P2] = Quote then Break;
    Inc(P2);
  end;
  Result := LowerCase(Copy(Sample, P, P2 - P));
end;

{ ============================================================
  Extract <language> tag value (first 4096 bytes, ASCII-safe)
  ============================================================ }
function ExtractLanguageTag(const Body: AnsiString): AnsiString;
var
  Sample, SL: AnsiString;
  P, P2: Integer;
begin
  Result := '';
  if Length(Body) > 4096 then
    Sample := Copy(Body, 1, 4096)
  else
    Sample := Body;
  SL := LowerCase(Sample);
  P := Pos('<language>', SL);
  if P = 0 then Exit;
  Inc(P, 10);
  P2 := P;
  while P2 <= Length(Sample) do
  begin
    if Sample[P2] in ['<', ' ', #13, #10] then Break;
    Inc(P2);
  end;
  Result := Trim(LowerCase(Copy(Sample, P, P2 - P)));
end;

{ ============================================================
  Map encoding name to Windows codepage number.
  Case-insensitive, handles common aliases.
  ============================================================ }
function EncodingNameToCodepage(const Name: AnsiString): DWORD;
var
  N: AnsiString;
begin
  Result := 0;
  N := Trim(LowerCase(Name));
  if N = '' then Exit;

  { Unicode }
  if (N = 'utf-8') or (N = 'utf8') then Result := 65001
  else if (N = 'utf-16') or (N = 'utf-16le') or
          (N = 'utf16') or (N = 'utf16le') then Result := 1200
  else if (N = 'utf-16be') or (N = 'utf16be') then Result := 1201

  { Cyrillic }
  else if (N = 'windows-1251') or (N = 'cp1251') or
          (N = 'x-cp1251') or (N = 'ansi-1251') then Result := 1251
  else if (N = 'koi8-r') or (N = 'koi8r') then Result := 20866
  else if (N = 'koi8-u') or (N = 'koi8u') then Result := 21866
  else if (N = 'iso-8859-5') or (N = 'iso_8859-5') then Result := 28595

  { Western / Latin-1 }
  else if (N = 'windows-1252') or (N = 'cp1252') or
          (N = 'iso-8859-1') or (N = 'iso_8859-1') or
          (N = 'latin-1') or (N = 'latin1') or
          (N = 'us-ascii') or (N = 'ascii') then Result := 1252

  { Central/Eastern European }
  else if (N = 'windows-1250') or (N = 'cp1250') then Result := 1250
  else if (N = 'iso-8859-2') or (N = 'iso_8859-2') then Result := 28592

  { Greek }
  else if (N = 'windows-1253') or (N = 'cp1253') then Result := 1253
  else if (N = 'iso-8859-7') or (N = 'iso_8859-7') then Result := 28597

  { Turkish }
  else if (N = 'windows-1254') or (N = 'cp1254') then Result := 1254
  else if (N = 'iso-8859-9') or (N = 'iso_8859-9') then Result := 28599

  { Hebrew }
  else if (N = 'windows-1255') or (N = 'cp1255') then Result := 1255
  else if (N = 'iso-8859-8') or (N = 'iso_8859-8') then Result := 28598

  { Arabic }
  else if (N = 'windows-1256') or (N = 'cp1256') then Result := 1256
  else if (N = 'iso-8859-6') or (N = 'iso_8859-6') then Result := 28596

  { Japanese }
  else if (N = 'shift_jis') or (N = 'shift-jis') or (N = 'sjis') or
          (N = 'x-sjis') or (N = 'ms_kanji') or (N = 'csshiftjis') then
    Result := 932
  else if (N = 'euc-jp') or (N = 'eucjp') or (N = 'x-euc-jp') or
          (N = 'cseucpkdfmtjapanese') then Result := 20932
  else if (N = 'iso-2022-jp') or (N = 'iso2022jp') then Result := 50220

  { Chinese Simplified }
  else if (N = 'gb2312') or (N = 'gbk') or (N = 'gb18030') or
          (N = 'hz-gb-2312') or (N = 'x-gbk') or
          (N = 'csgb2312') then Result := 936

  { Chinese Traditional }
  else if (N = 'big5') or (N = 'big5-hkscs') or
          (N = 'csbig5') then Result := 950

  { Korean }
  else if (N = 'euc-kr') or (N = 'euckr') or
          (N = 'ks_c_5601-1987') or (N = 'windows-949') or
          (N = 'ms949') then Result := 51949

  { Thai }
  else if (N = 'tis-620') or (N = 'windows-874') or
          (N = 'iso-8859-11') then Result := 874;
end;

{ ============================================================
  Byte pattern analysis.
  Scans up to 64 KB, returns best-guess codepage or 0.
  Language tag (ASCII-safe in any encoding) is used to
  disambiguate between encodings with overlapping byte ranges.
  ============================================================ }
function AnalyzeBytePatterns(const Body: AnsiString;
  const Lang: AnsiString): DWORD;
var
  I, SampleLen: Integer;
  B, B1, B2: Byte;
  ScoreSJIS: Integer;
  ScoreEUCJP: Integer;
  ScoreGBK: Integer;
  ScoreEUCKR: Integer;
  ScoreCyrillic: Integer;
  ScoreISO2022JP: Integer;
  IsJa, IsZh, IsKo, IsCyrillic: Boolean;
  LangBase: AnsiString;
begin
  Result := 0;
  if Length(Body) > 65536 then
    SampleLen := 65536
  else
    SampleLen := Length(Body);

  ScoreSJIS      := 0;
  ScoreEUCJP     := 0;
  ScoreGBK       := 0;
  ScoreEUCKR     := 0;
  ScoreCyrillic  := 0;
  ScoreISO2022JP := 0;

  LangBase := Copy(Lang, 1, 2);
  IsJa      := LangBase = 'ja';
  IsZh      := LangBase = 'zh';
  IsKo      := LangBase = 'ko';
  IsCyrillic := (LangBase = 'ru') or (LangBase = 'uk') or
                (LangBase = 'be') or (LangBase = 'bg') or
                (LangBase = 'sr') or (LangBase = 'mk');

  I := 1;
  while I <= SampleLen do
  begin
    B := Byte(Body[I]);

    { ISO-2022-JP: ESC $ B / ESC $ @ / ESC ( B / ESC ( J }
    if (B = $1B) and (I + 2 <= SampleLen) then
    begin
      B1 := Byte(Body[I + 1]);
      B2 := Byte(Body[I + 2]);
      if (B1 = $24) and ((B2 = $42) or (B2 = $40)) then
        Inc(ScoreISO2022JP, 10)
      else if (B1 = $28) and ((B2 = $42) or (B2 = $4A)) then
        Inc(ScoreISO2022JP, 5);
      Inc(I);
      Continue;
    end;

    { Pure ASCII — single byte }
    if B < $80 then
    begin
      Inc(I);
      Continue;
    end;

    { Count bytes in Cyrillic range for Windows-1251 heuristic.
      0xC0-0xFF covers both lowercase and uppercase Cyrillic in 1251. }
    if B >= $C0 then
      Inc(ScoreCyrillic);

    { Need a second byte for multi-byte analysis }
    if I >= SampleLen then Break;
    B1 := Byte(Body[I + 1]);

    { EUC-JP half-width kana: 0x8E + 0xA1-0xDF }
    if (B = $8E) and (B1 >= $A1) and (B1 <= $DF) then
    begin
      Inc(ScoreEUCJP, 3);
      Inc(I, 2);
      Continue;
    end;

    { EUC-JP JIS X 0212 prefix: 0x8F + 0xA1-0xFE + 0xA1-0xFE }
    if (B = $8F) and (I + 2 <= SampleLen) then
    begin
      B2 := Byte(Body[I + 2]);
      if (B1 >= $A1) and (B1 <= $FE) and
         (B2 >= $A1) and (B2 <= $FE) then
      begin
        Inc(ScoreEUCJP, 3);
        Inc(I, 3);
        Continue;
      end;
    end;

    { Shift-JIS lead bytes: 0x81-0x9F or 0xE0-0xFC.
      Trail bytes: 0x40-0x7E or 0x80-0xFC (excluding 0x7F). }
    if ((B >= $81) and (B <= $9F)) or
       ((B >= $E0) and (B <= $FC)) then
    begin
      if ((B1 >= $40) and (B1 <= $7E)) or
         ((B1 >= $80) and (B1 <= $FC) and (B1 <> $7F)) then
      begin
        Inc(ScoreSJIS, 2);
        Inc(I, 2);
        Continue;
      end;
    end;

    { EUC-JP main block: 0xA1-0xFE + 0xA1-0xFE.
      Also overlaps with EUC-KR Hangul (0xB0-0xC8 first byte). }
    if (B >= $A1) and (B <= $FE) and
       (B1 >= $A1) and (B1 <= $FE) then
    begin
      Inc(ScoreEUCJP, 2);
      { EUC-KR core Hangul block: first byte 0xB0-0xC8 }
      if (B >= $B0) and (B <= $C8) then
        Inc(ScoreEUCKR, 2);
      Inc(I, 2);
      Continue;
    end;

    { GBK/GB2312: lead 0x81-0xFE, trail 0x40-0xFE (not 0x7F).
      Covers Simplified Chinese and also Korean (CP949 = extended GBK). }
    if (B >= $81) and (B <= $FE) and
       (B1 >= $40) and (B1 <= $FE) and (B1 <> $7F) then
    begin
      Inc(ScoreGBK, 2);
      Inc(I, 2);
      Continue;
    end;

    Inc(I);
  end;

  { ISO-2022-JP: escape sequences are definitive }
  if ScoreISO2022JP >= 5 then
  begin
    Result := 50220;
    Exit;
  end;

  { Language tag is the primary discriminator for CJK encodings.
    Byte scoring alone cannot reliably separate Shift-JIS / EUC-JP /
    GB2312 / EUC-KR because their byte ranges overlap. }

  if IsJa then
  begin
    { Japanese: Shift-JIS vs EUC-JP.
      Shift-JIS is overwhelmingly more common for modern Japanese web.
      Give EUC-JP a bonus multiplier to offset the common-case bias. }
    if ScoreEUCJP * 3 > ScoreSJIS * 2 then
      Result := 20932  { EUC-JP }
    else
      Result := 932;   { Shift-JIS }
    Exit;
  end;

  if IsZh then
  begin
    { Chinese: GB2312/GBK (Simplified) vs Big5 (Traditional).
      GBK byte patterns score higher for Simplified content.
      lang="zh" without subtag → assume Simplified = GBK. }
    if ScoreGBK > 0 then
      Result := 936    { GBK/GB2312 }
    else
      Result := 950;   { Big5 fallback }
    Exit;
  end;

  if IsKo then
  begin
    Result := 51949;   { EUC-KR }
    Exit;
  end;

  { No CJK language tag — use byte scores with thresholds }

  { Cyrillic: threshold of 3 non-ASCII bytes in range 0xC0-0xFF }
  if ScoreCyrillic >= 3 then
  begin
    { KOI8-R Cyrillic maps 0xC0-0xFF but reversed vs Windows-1251.
      Without explicit declaration, Windows-1251 is more common
      for RSS feeds from Russian sites.
      If language tag is explicitly Cyrillic, use 1251.
      Without lang tag, still prefer 1251 as safer default. }
    if IsCyrillic then
      Result := 1251
    else
      Result := 1251;
    Exit;
  end;

  { Pure byte-score race for unlabelled CJK }
  if (ScoreSJIS > 0) or (ScoreEUCJP > 0) or
     (ScoreGBK > 0) or (ScoreEUCKR > 0) then
  begin
    if (ScoreSJIS >= ScoreEUCJP) and
       (ScoreSJIS >= ScoreGBK) and
       (ScoreSJIS >= ScoreEUCKR) then
      Result := 932
    else if (ScoreEUCJP >= ScoreGBK) and
            (ScoreEUCJP >= ScoreEUCKR) then
      Result := 20932
    else if ScoreGBK >= ScoreEUCKR then
      Result := 936
    else
      Result := 51949;
    Exit;
  end;
end;

{ ============================================================
  DetectEncoding — 6-stage cascade
  ============================================================ }
function DetectEncoding(const Body: AnsiString;
  const ContentType: AnsiString): DWORD;
var
  CP: DWORD;
  EncName: AnsiString;
  Lang: AnsiString;
begin
  Result := CP_UTF8;

  { Stage 1: BOM }
  CP := DetectBOM(Body);
  if CP > 0 then begin Result := CP; Exit; end;

  { Stage 2: HTTP Content-Type }
  if ContentType <> '' then
  begin
    EncName := ExtractContentTypeCharset(ContentType);
    if EncName <> '' then
    begin
      CP := EncodingNameToCodepage(EncName);
      if CP > 0 then begin Result := CP; Exit; end;
    end;
  end;

  { Stage 3: XML declaration }
  EncName := ExtractXmlEncoding(Body);
  if EncName <> '' then
  begin
    CP := EncodingNameToCodepage(EncName);
    if CP > 0 then begin Result := CP; Exit; end;
  end;

  { Stage 4: Full UTF-8 validation (entire body) }
  if IsValidUtf8(Body) then begin Result := CP_UTF8; Exit; end;

  { Stage 5: Language tag + byte pattern analysis }
  Lang := ExtractLanguageTag(Body);
  CP := AnalyzeBytePatterns(Body, Lang);
  if CP > 0 then begin Result := CP; Exit; end;

  { Stage 6: Fallback — Windows-1252 (superset of Latin-1) }
  Result := 1252;
end;

{ ============================================================
  BodyToUnicode — convert any encoding directly to UnicodeString
  Uses Windows MultiByteToWideChar; no FPC UTF8Decode involved.
  This is the reliable path: Win API handles all 256-value
  codepage tables, UTF-8, and ISO-2022-JP correctly.
  ============================================================ }
function BodyToUnicode(const Body: AnsiString; CP: DWORD): UnicodeString;
var
  WLen: Integer;
  Src: AnsiString;
  TmpWide: array of WideChar;
  I: Integer;
  TmpB: Byte;
begin
  Result := '';
  if Length(Body) = 0 then Exit;

  { UTF-16 LE: just cast the bytes }
  if CP = CP_UTF16LE then
  begin
    Src := Body;
    if (Length(Src) >= 2) and
       (Byte(Src[1]) = $FF) and (Byte(Src[2]) = $FE) then
      Src := Copy(Src, 3, MaxInt);
    WLen := Length(Src) div 2;
    if WLen = 0 then Exit;
    SetLength(Result, WLen);
    Move(Src[1], Result[1], WLen * SizeOf(WideChar));
    Exit;
  end;

  { UTF-16 BE: swap bytes then cast }
  if CP = CP_UTF16BE then
  begin
    Src := Body;
    if (Length(Src) >= 2) and
       (Byte(Src[1]) = $FE) and (Byte(Src[2]) = $FF) then
      Src := Copy(Src, 3, MaxInt);
    { Ensure even length }
    if (Length(Src) and 1) = 1 then
      SetLength(Src, Length(Src) - 1);
    I := 1;
    while I + 1 <= Length(Src) do
    begin
      TmpB := Byte(Src[I]);
      Src[I] := Src[I + 1];
      Src[I + 1] := AnsiChar(TmpB);
      Inc(I, 2);
    end;
    WLen := Length(Src) div 2;
    if WLen = 0 then Exit;
    SetLength(Result, WLen);
    Move(Src[1], Result[1], WLen * SizeOf(WideChar));
    Exit;
  end;

  { UTF-8 and all MBCS/SBCS codepages via Windows API }
  WLen := MultiByteToWideChar(CP, 0, PAnsiChar(Body),
    Length(Body), nil, 0);
  if WLen <= 0 then
  begin
    { Codepage failed — fall back to UTF-8 }
    WLen := MultiByteToWideChar(CP_UTF8, 0, PAnsiChar(Body),
      Length(Body), nil, 0);
    if WLen <= 0 then Exit;
    CP := CP_UTF8;
  end;

  SetLength(TmpWide, WLen + 1);
  MultiByteToWideChar(CP, 0, PAnsiChar(Body),
    Length(Body), @TmpWide[0], WLen);
  TmpWide[WLen] := #0;

  SetLength(Result, WLen);
  Move(TmpWide[0], Result[1], WLen * SizeOf(WideChar));
end;

{ ============================================================
  NormalizeToUtf8 — convert from detected CP to UTF-8
  ============================================================ }
function NormalizeToUtf8(const Body: AnsiString;
  CP: DWORD): AnsiString;
var
  WBuf: array of WideChar;
  OutBuf: array of Byte;
  WLen, OutLen: Integer;
  Src: AnsiString;
  I: Integer;
  TmpB: Byte;
begin
  { Already UTF-8 }
  if CP = CP_UTF8 then
  begin
    Result := Body;
    Exit;
  end;

  { UTF-16 BE → swap bytes to LE, then process as LE }
  if CP = CP_UTF16BE then
  begin
    Src := Body;
    { Skip FE FF BOM if present }
    if (Length(Src) >= 2) and
       (Byte(Src[1]) = $FE) and (Byte(Src[2]) = $FF) then
      Src := Copy(Src, 3, MaxInt);
    { Swap byte pairs }
    I := 1;
    while I + 1 <= Length(Src) do
    begin
      TmpB := Byte(Src[I]);
      Src[I] := Src[I + 1];
      Src[I + 1] := AnsiChar(TmpB);
      Inc(I, 2);
    end;
    Result := NormalizeToUtf8(Src, CP_UTF16LE);
    Exit;
  end;

  { UTF-16 LE }
  if CP = CP_UTF16LE then
  begin
    Src := Body;
    { Skip FF FE BOM }
    if (Length(Src) >= 2) and
       (Byte(Src[1]) = $FF) and (Byte(Src[2]) = $FE) then
      Src := Copy(Src, 3, MaxInt);
    WLen := Length(Src) div 2;
    if WLen = 0 then begin Result := ''; Exit; end;
    SetLength(WBuf, WLen + 1);
    Move(Src[1], WBuf[0], WLen * SizeOf(WideChar));
    WBuf[WLen] := #0;
    OutLen := WideCharToMultiByte(CP_UTF8, 0, @WBuf[0], WLen,
      nil, 0, nil, nil);
    if OutLen <= 0 then begin Result := ''; Exit; end;
    SetLength(OutBuf, OutLen);
    WideCharToMultiByte(CP_UTF8, 0, @WBuf[0], WLen,
      @OutBuf[0], OutLen, nil, nil);
    SetLength(Result, OutLen);
    Move(OutBuf[0], Result[1], OutLen);
    Exit;
  end;

  { Any other codepage: CP → WideChar → UTF-8 }
  WLen := MultiByteToWideChar(CP, 0, PAnsiChar(Body),
    Length(Body), nil, 0);
  if WLen <= 0 then begin Result := Body; Exit; end;

  SetLength(WBuf, WLen + 1);
  MultiByteToWideChar(CP, 0, PAnsiChar(Body),
    Length(Body), @WBuf[0], WLen);
  WBuf[WLen] := #0;

  OutLen := WideCharToMultiByte(CP_UTF8, 0, @WBuf[0], WLen,
    nil, 0, nil, nil);
  if OutLen <= 0 then begin Result := Body; Exit; end;

  SetLength(OutBuf, OutLen);
  WideCharToMultiByte(CP_UTF8, 0, @WBuf[0], WLen,
    @OutBuf[0], OutLen, nil, nil);
  SetLength(Result, OutLen);
  Move(OutBuf[0], Result[1], OutLen);
end;

end.
