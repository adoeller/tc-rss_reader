{ ============================================================
  rss_config.pas — INI-Konfiguration lesen/schreiben
  ============================================================ }
unit rss_config;

{$MODE ObjFPC}{$H+}

interface

uses
  Windows, SysUtils, Classes, IniFiles, rss_types;

var
  GConfig: TPluginConfig;
  GIniReady: Boolean;

procedure ConfigInit(const IniPath: AnsiString);
procedure ConfigLoad;
procedure ConfigSave;
procedure ConfigAddFeed(const URL, Title: UnicodeString);
procedure ConfigRemoveFeed(const Title: UnicodeString);
function  ConfigGetFeedURL(const Title: UnicodeString): UnicodeString;
procedure ConfigUpdateLastFetch(const Title: UnicodeString;
  DT: TDateTime; ItemCount: Integer);
function  ConfigGetLastFetch(const Title: UnicodeString): TDateTime;
function  ConfigGetPrevLastFetch(const Title: UnicodeString): TDateTime;
function  ConfigGetItemCount(const Title: UnicodeString): Integer;
function  ConfigGetTemplatePath: UnicodeString;
function  ConfigGetTemplatePathDark: UnicodeString;
procedure ConfigLoadTemplate;
procedure ConfigEnumTemplates(out List: TStringList);
function  ConfigGetActiveTemplate: UnicodeString;

implementation

uses
  rss_log, rss_crypto, rss_theme;

const
  ENC_PREFIX: UnicodeString = '$ENC$';

function EncryptIfNeeded(const Plain: UnicodeString): UnicodeString;
var
  Cipher: UnicodeString;
begin
  Result := '';
  if Plain = '' then
    Exit;
  Cipher := EncryptString(Plain);
  if Cipher <> '' then
    Result := ENC_PREFIX + Cipher
  else
    Result := Plain;
end;

function DecryptIfNeeded(const Stored: UnicodeString): UnicodeString;
var
  Cipher: UnicodeString;
begin
  Result := Stored;
  if Stored = '' then
    Exit;
  if Copy(Stored, 1, Length(ENC_PREFIX)) = ENC_PREFIX then
  begin
    Cipher := Copy(Stored, Length(ENC_PREFIX) + 1, MaxInt);
    Result := DecryptString(Cipher);
  end;
end;

procedure ConfigInit(const IniPath: AnsiString);
var
  Buf: array[0..MAX_PATH] of WideChar;
  PluginDir: UnicodeString;
begin
  { INI-Datei im Plugin-Verzeichnis (neben der .wfx64) }
  FillChar(Buf, SizeOf(Buf), 0);
  GetModuleFileNameW(HInstance, @Buf[0], MAX_PATH);
  PluginDir := ExtractFilePath(UnicodeString(PWideChar(@Buf[0])));
  GConfig.IniPath := PluginDir + 'wfx_rss.ini';
  GIniReady := True;
end;

procedure ConfigLoad;
var
  Ini: TIniFile;
  Sections: TStringList;
  I: Integer;
  Sect: String;
  Count: Integer;
begin
  if not GIniReady then
    Exit;

  Sections := nil;
  Ini := nil;
  try
    Ini := TIniFile.Create(UTF8Encode(GConfig.IniPath));
    Sections := TStringList.Create;

    GConfig.TemplateName := UnicodeString(
      Ini.ReadString('Config', 'Template', 'Default.tmpl'));
    GConfig.TemplateNameDark := UnicodeString(
      Ini.ReadString('Config', 'TemplateDark', 'Default.dark.tmpl'));
    GConfig.Proxy.ProxyType :=
      Ini.ReadInteger('Config', 'ProxyType', 0);
    GConfig.Proxy.Server := UnicodeString(
      Ini.ReadString('Config', 'ProxyServer', ''));
    GConfig.Proxy.Port :=
      Ini.ReadInteger('Config', 'ProxyPort', 0);
    GConfig.Proxy.User := UnicodeString(
      Ini.ReadString('Config', 'ProxyUser', ''));
    GConfig.Proxy.Password := DecryptIfNeeded(UnicodeString(
      Ini.ReadString('Config', 'ProxyPassword', '')));
    GConfig.RefreshX :=
      Ini.ReadInteger('Config', 'Refresh_X', 200);
    GConfig.RefreshY :=
      Ini.ReadInteger('Config', 'Refresh_Y', 200);
    GConfig.OpenLinksNewWindow :=
      Ini.ReadBool('Config', 'OpenLinksNewWindow', False);

    Ini.ReadSections(Sections);
    Count := 0;
    for I := 0 to Sections.Count - 1 do
    begin
      Sect := Sections[I];
      if CompareText(Sect, 'Config') <> 0 then
        Inc(Count);
    end;

    SetLength(GConfig.FeedURLs, Count);
    SetLength(GConfig.FeedTitles, Count);
    SetLength(GConfig.FeedLastFetch, Count);
    SetLength(GConfig.FeedPrevLastFetch, Count);
    SetLength(GConfig.FeedItemCount, Count);
    Count := 0;
    for I := 0 to Sections.Count - 1 do
    begin
      Sect := Sections[I];
      if CompareText(Sect, 'Config') <> 0 then
      begin
        GConfig.FeedURLs[Count] := UnicodeString(Sect);
        GConfig.FeedTitles[Count] := UnicodeString(
          Ini.ReadString(Sect, 'Title', Sect));
        GConfig.FeedLastFetch[Count] :=
          Ini.ReadFloat(Sect, 'LastFetch', 0);
        { PrevLastFetch = the fetch before the last one, own INI field }
        GConfig.FeedPrevLastFetch[Count] :=
          Ini.ReadFloat(Sect, 'LastFetchPrev', 0);
        GConfig.FeedItemCount[Count] :=
          Ini.ReadInteger(Sect, 'ItemCount', 0);
        Inc(Count);
      end;
    end;

    LogMsg('Config loaded: ' +
      IntToStr(Length(GConfig.FeedURLs)) + ' feeds');

    ConfigLoadTemplate;
  finally
    Ini.Free;
    Sections.Free;
  end;
end;

procedure ConfigSave;
var
  Ini: TIniFile;
  I: Integer;
begin
  if not GIniReady then
    Exit;

  Ini := nil;
  try
    if FileExists(UTF8Encode(GConfig.IniPath)) then
      DeleteFile(UTF8Encode(GConfig.IniPath));

    Ini := TIniFile.Create(UTF8Encode(GConfig.IniPath));

    Ini.WriteString('Config', 'Template',
      AnsiString(GConfig.TemplateName));
    Ini.WriteString('Config', 'TemplateDark',
      AnsiString(GConfig.TemplateNameDark));
    Ini.WriteInteger('Config', 'ProxyType',
      GConfig.Proxy.ProxyType);
    Ini.WriteString('Config', 'ProxyServer',
      AnsiString(GConfig.Proxy.Server));
    Ini.WriteInteger('Config', 'ProxyPort',
      GConfig.Proxy.Port);
    Ini.WriteString('Config', 'ProxyUser',
      AnsiString(GConfig.Proxy.User));
    Ini.WriteString('Config', 'ProxyPassword',
      AnsiString(EncryptIfNeeded(GConfig.Proxy.Password)));
    Ini.WriteInteger('Config', 'Refresh_X', GConfig.RefreshX);
    Ini.WriteInteger('Config', 'Refresh_Y', GConfig.RefreshY);
    Ini.WriteBool('Config', 'OpenLinksNewWindow',
      GConfig.OpenLinksNewWindow);

    for I := 0 to Length(GConfig.FeedURLs) - 1 do
    begin
      Ini.WriteString(AnsiString(GConfig.FeedURLs[I]),
        'Title', AnsiString(GConfig.FeedTitles[I]));
      if (I < Length(GConfig.FeedLastFetch)) and
        (GConfig.FeedLastFetch[I] > 0) then
      begin
        Ini.WriteFloat(AnsiString(GConfig.FeedURLs[I]),
          'LastFetch', GConfig.FeedLastFetch[I]);
        Ini.WriteString(AnsiString(GConfig.FeedURLs[I]),
          'LastFetchDate', AnsiString(
            FormatDateTime('yyyy-mm-dd hh:nn:ss',
              GConfig.FeedLastFetch[I])));
        { Save the previous fetch time for new-article detection }
        if (I < Length(GConfig.FeedPrevLastFetch)) and
          (GConfig.FeedPrevLastFetch[I] > 0) then
          Ini.WriteFloat(AnsiString(GConfig.FeedURLs[I]),
            'LastFetchPrev', GConfig.FeedPrevLastFetch[I]);
      end;
      if (I < Length(GConfig.FeedItemCount)) and
        (GConfig.FeedItemCount[I] > 0) then
        Ini.WriteInteger(AnsiString(GConfig.FeedURLs[I]),
          'ItemCount', GConfig.FeedItemCount[I]);
    end;

    Ini.UpdateFile;
    LogMsg('Config saved');
  finally
    Ini.Free;
  end;
end;

procedure ConfigAddFeed(const URL, Title: UnicodeString);
var
  N: Integer;
begin
  N := Length(GConfig.FeedURLs);
  SetLength(GConfig.FeedURLs, N + 1);
  SetLength(GConfig.FeedTitles, N + 1);
  SetLength(GConfig.FeedLastFetch, N + 1);
  SetLength(GConfig.FeedPrevLastFetch, N + 1);
  SetLength(GConfig.FeedItemCount, N + 1);
  GConfig.FeedURLs[N] := URL;
  GConfig.FeedTitles[N] := Title;
  GConfig.FeedLastFetch[N] := 0;
  GConfig.FeedPrevLastFetch[N] := 0;
  GConfig.FeedItemCount[N] := 0;
  ConfigSave;
end;

procedure ConfigRemoveFeed(const Title: UnicodeString);
var
  I, J, N: Integer;
  Found: Boolean;
begin
  N := Length(GConfig.FeedURLs);
  Found := False;
  for I := 0 to N - 1 do
  begin
    if GConfig.FeedTitles[I] = Title then
    begin
      Found := True;
      for J := I to N - 2 do
      begin
        GConfig.FeedURLs[J] := GConfig.FeedURLs[J + 1];
        GConfig.FeedTitles[J] := GConfig.FeedTitles[J + 1];
        GConfig.FeedLastFetch[J] := GConfig.FeedLastFetch[J + 1];
        GConfig.FeedPrevLastFetch[J] := GConfig.FeedPrevLastFetch[J + 1];
        GConfig.FeedItemCount[J] := GConfig.FeedItemCount[J + 1];
      end;
      SetLength(GConfig.FeedURLs, N - 1);
      SetLength(GConfig.FeedTitles, N - 1);
      SetLength(GConfig.FeedLastFetch, N - 1);
      SetLength(GConfig.FeedPrevLastFetch, N - 1);
      SetLength(GConfig.FeedItemCount, N - 1);
      Break;
    end;
  end;
  if Found then
    ConfigSave;
end;

function ConfigGetFeedURL(const Title: UnicodeString): UnicodeString;
var
  I: Integer;
begin
  Result := '';
  for I := 0 to Length(GConfig.FeedTitles) - 1 do
  begin
    if GConfig.FeedTitles[I] = Title then
    begin
      Result := GConfig.FeedURLs[I];
      Exit;
    end;
  end;
end;

procedure ConfigUpdateLastFetch(const Title: UnicodeString;
  DT: TDateTime; ItemCount: Integer);
var
  I: Integer;
begin
  for I := 0 to Length(GConfig.FeedTitles) - 1 do
  begin
    if GConfig.FeedTitles[I] = Title then
    begin
      { Rotate: old LastFetch becomes PrevLastFetch }
      if (I < Length(GConfig.FeedPrevLastFetch)) and
         (I < Length(GConfig.FeedLastFetch)) and
         (GConfig.FeedLastFetch[I] > 0) then
        GConfig.FeedPrevLastFetch[I] := GConfig.FeedLastFetch[I];
      if I < Length(GConfig.FeedLastFetch) then
        GConfig.FeedLastFetch[I] := DT;
      if I < Length(GConfig.FeedItemCount) then
        GConfig.FeedItemCount[I] := ItemCount;
      ConfigSave;
      Exit;
    end;
  end;
end;

function ConfigGetLastFetch(const Title: UnicodeString): TDateTime;
var
  I: Integer;
begin
  Result := 0;
  for I := 0 to Length(GConfig.FeedTitles) - 1 do
  begin
    if GConfig.FeedTitles[I] = Title then
    begin
      if I < Length(GConfig.FeedLastFetch) then
        Result := GConfig.FeedLastFetch[I];
      Exit;
    end;
  end;
end;

function ConfigGetPrevLastFetch(const Title: UnicodeString): TDateTime;
var
  I: Integer;
begin
  Result := 0;
  for I := 0 to Length(GConfig.FeedTitles) - 1 do
    if GConfig.FeedTitles[I] = Title then
    begin
      if I < Length(GConfig.FeedPrevLastFetch) then
        Result := GConfig.FeedPrevLastFetch[I];
      Exit;
    end;
end;

function ConfigGetItemCount(const Title: UnicodeString): Integer;
var
  I: Integer;
begin
  Result := 0;
  for I := 0 to Length(GConfig.FeedTitles) - 1 do
  begin
    if GConfig.FeedTitles[I] = Title then
    begin
      if I < Length(GConfig.FeedItemCount) then
        Result := GConfig.FeedItemCount[I];
      Exit;
    end;
  end;
end;

function ConfigGetTemplatePath: UnicodeString;
var
  Dir: UnicodeString;
begin
  Dir := ExtractFilePath(GConfig.IniPath);
  Result := Dir + GConfig.TemplateName;
end;

function ConfigGetTemplatePathDark: UnicodeString;
var
  Dir: UnicodeString;
begin
  Dir := ExtractFilePath(GConfig.IniPath);
  Result := Dir + GConfig.TemplateNameDark;
end;

const
  BUILTIN_LIGHT_TPL: UnicodeString =
    '<html>'#13#10 +
    '<head><meta charset="utf-8"><title><%title%></title></head>'#13#10 +
    '<body style="font-family:Segoe UI,Arial,sans-serif;margin:10px;background:#fff;color:#222;">'#13#10 +
    '<h2><%title%></h2>'#13#10 +
    '<p style="color:#666;"><%pubDate%></p>'#13#10 +
    '<p><%description%></p>'#13#10 +
    '<p><a href="<%link%>">Read article</a></p>'#13#10 +
    '<hr>'#13#10 +
    '<small>Author: <%author%> | Category: <%category%></small>'#13#10 +
    '</body></html>';

  BUILTIN_DARK_TPL: UnicodeString =
    '<html>'#13#10 +
    '<head><meta charset="utf-8"><title><%title%></title>'#13#10 +
    '<style>body{background:#1e1e1e;color:#e0e0e0;font-family:Segoe UI,Arial,sans-serif;margin:10px;}'#13#10 +
    'a{color:#5fb4ff;} a:visited{color:#b07fff;} hr{border-color:#444;} h2{color:#fff;}</style>'#13#10 +
    '</head>'#13#10 +
    '<body>'#13#10 +
    '<h2><%title%></h2>'#13#10 +
    '<p style="color:#999;"><%pubDate%></p>'#13#10 +
    '<p><%description%></p>'#13#10 +
    '<p><a href="<%link%>">Read article</a></p>'#13#10 +
    '<hr>'#13#10 +
    '<small>Author: <%author%> | Category: <%category%></small>'#13#10 +
    '</body></html>';

procedure ConfigLoadTemplate;
var
  TmplPath: UnicodeString;
  SL: TStringList;
begin
  GConfig.TemplateContent := '';
  GConfig.TemplateContentDark := '';

  { Light template }
  TmplPath := ConfigGetTemplatePath;
  if FileExists(UTF8Encode(TmplPath)) then
  begin
    SL := nil;
    try
      SL := TStringList.Create;
      SL.LoadFromFile(UTF8Encode(TmplPath));
      GConfig.TemplateContent := UnicodeString(SL.Text);
    finally
      SL.Free;
    end;
  end;
  if GConfig.TemplateContent = '' then
    GConfig.TemplateContent := BUILTIN_LIGHT_TPL;

  { Dark template }
  TmplPath := ConfigGetTemplatePathDark;
  if FileExists(UTF8Encode(TmplPath)) then
  begin
    SL := nil;
    try
      SL := TStringList.Create;
      SL.LoadFromFile(UTF8Encode(TmplPath));
      GConfig.TemplateContentDark := UnicodeString(SL.Text);
    finally
      SL.Free;
    end;
  end;
  if GConfig.TemplateContentDark = '' then
    GConfig.TemplateContentDark := BUILTIN_DARK_TPL;
end;

procedure ConfigEnumTemplates(out List: TStringList);
var
  Dir: UnicodeString;
  SR: TSearchRec;
  R: Integer;
begin
  List := TStringList.Create;
  Dir := ExtractFilePath(GConfig.IniPath);
  R := FindFirst(UTF8Encode(Dir + '*.tmpl'), faAnyFile, SR);
  while R = 0 do
  begin
    if (SR.Attr and faDirectory) = 0 then
      List.Add(SR.Name);
    R := FindNext(SR);
  end;
  FindClose(SR);
  List.Sort;
end;

function ConfigGetActiveTemplate: UnicodeString;
begin
  if IsSystemDarkMode and (GConfig.TemplateContentDark <> '') then
    Result := GConfig.TemplateContentDark
  else
    Result := GConfig.TemplateContent;
end;

end.
