{ ============================================================
  rss_dialog.pas — Win32-Konfigurationsdialog

  EXAKTE Kopie des bewährten Musters aus GitHubFS ConfigDlg.pas:
  - FillChar statt Default
  - WideString fuer Klassennamen
  - GetMessage (nicht GetMessageW)
  - IsDialogMessage (nicht IsDialogMessageW)
  - PostQuitMessage in WM_DESTROY
  - WS_EX_TOPMOST damit Fenster sichtbar
  ============================================================ }
unit rss_dialog;

{$MODE ObjFPC}{$H+}

interface

uses
  Windows, SysUtils, rss_types;

procedure ShowConfigDialog(hParent: HWND);

implementation

uses
  rss_log, rss_config, rss_vfs, rss_http, rss_parser;

const
  IDC_FEED_LIST  = 1001;
  IDC_BTN_ADD    = 1010;
  IDC_BTN_REMOVE = 1011;
  IDC_BTN_TEST   = 1012;
  IDC_BTN_CLOSE  = 1014;
  IDC_EDIT_URL   = 1020;
  IDC_EDIT_TITLE = 1021;
  IDC_LBL_INI    = 1031;

{ ============================================================ }
procedure RefreshList(hDlg: HWND);
var
  hList: HWND;
  I: Integer;
  S: WideString;
begin
  hList := GetDlgItem(hDlg, IDC_FEED_LIST);
  SendMessageW(hList, LB_RESETCONTENT, 0, 0);
  for I := 0 to Length(GConfig.FeedTitles)-1 do
  begin
    S := WideString(GConfig.FeedTitles[I]) +
      '  [' + WideString(GConfig.FeedURLs[I]) + ']';
    SendMessageW(hList, LB_ADDSTRING, 0,
      LPARAM(PWideChar(S)));
  end;
  SetDlgItemTextW(hDlg, IDC_LBL_INI,
    PWideChar(WideString('INI: ' + GConfig.IniPath)));
end;

{ ============================================================ }
procedure DoTestFeed(hDlg: HWND; const URL: UnicodeString);
var
  Body: AnsiString;
  ErrMsg: UnicodeString;
  Feed: TRssFeed;
  Msg: WideString;
begin
  Body := '';
  ErrMsg := '';
  FillChar(Feed, SizeOf(Feed), 0);
  Feed := Default(TRssFeed);
  if not HttpGet(URL, Body, ErrMsg) then
  begin
    MessageBoxW(hDlg, PWideChar(WideString('Error: ' + ErrMsg)),
      'Test', MB_OK or MB_ICONERROR);
    Exit;
  end;
  if not ParseRssFeed(Body, URL, Feed, ErrMsg) then
  begin
    MessageBoxW(hDlg, PWideChar(WideString('Parse error: ' + ErrMsg)),
      'Test', MB_OK or MB_ICONERROR);
    Exit;
  end;
  Msg := 'OK! ' + WideString(Feed.Title) + ' — ' +
    WideString(IntToStr(Length(Feed.Items))) + ' entries';
  MessageBoxW(hDlg, PWideChar(Msg), 'Test',
    MB_OK or MB_ICONINFORMATION);
end;

{ ============================================================ }
function CfgWndProc(hWin: HWND; uMsg: UINT;
  wParam: WPARAM; lParam: LPARAM): LRESULT; stdcall;
var
  Cmd: Integer;
  UrlBuf: array[0..1023] of WideChar;
  TtlBuf: array[0..255] of WideChar;
  URL, Title: UnicodeString;
  Sel: Integer;
  hL: HWND;
  WndRect: TRect;
begin
  Result := 0;
  case uMsg of

    WM_CREATE:
    begin
      CreateWindowExW(0, 'STATIC', 'Feed URL:',
        WS_CHILD or WS_VISIBLE, 10, 12, 75, 18,
        hWin, 0, HInstance, nil);
      CreateWindowExW(WS_EX_CLIENTEDGE, 'EDIT', '',
        WS_CHILD or WS_VISIBLE or ES_AUTOHSCROLL or WS_TABSTOP,
        90, 10, 390, 20, hWin,
        HMENU(PtrUInt(IDC_EDIT_URL)), HInstance, nil);

      CreateWindowExW(0, 'STATIC', 'Title:',
        WS_CHILD or WS_VISIBLE, 10, 38, 75, 18,
        hWin, 0, HInstance, nil);
      CreateWindowExW(WS_EX_CLIENTEDGE, 'EDIT', '',
        WS_CHILD or WS_VISIBLE or ES_AUTOHSCROLL or WS_TABSTOP,
        90, 36, 390, 20, hWin,
        HMENU(PtrUInt(IDC_EDIT_TITLE)), HInstance, nil);

      CreateWindowExW(0, 'BUTTON', 'Add',
        WS_CHILD or WS_VISIBLE or WS_TABSTOP,
        10, 64, 115, 26, hWin,
        HMENU(PtrUInt(IDC_BTN_ADD)), HInstance, nil);
      CreateWindowExW(0, 'BUTTON', 'Remove',
        WS_CHILD or WS_VISIBLE or WS_TABSTOP,
        130, 64, 115, 26, hWin,
        HMENU(PtrUInt(IDC_BTN_REMOVE)), HInstance, nil);
      CreateWindowExW(0, 'BUTTON', 'Test',
        WS_CHILD or WS_VISIBLE or WS_TABSTOP,
        250, 64, 115, 26, hWin,
        HMENU(PtrUInt(IDC_BTN_TEST)), HInstance, nil);

      CreateWindowExW(WS_EX_CLIENTEDGE, 'LISTBOX', '',
        WS_CHILD or WS_VISIBLE or WS_VSCROLL or WS_TABSTOP or
        LBS_NOTIFY or LBS_NOINTEGRALHEIGHT,
        10, 98, 470, 250, hWin,
        HMENU(PtrUInt(IDC_FEED_LIST)), HInstance, nil);

      CreateWindowExW(0, 'STATIC', '',
        WS_CHILD or WS_VISIBLE,
        10, 356, 470, 16, hWin,
        HMENU(PtrUInt(IDC_LBL_INI)), HInstance, nil);

      CreateWindowExW(0, 'BUTTON', 'Close',
        WS_CHILD or WS_VISIBLE or BS_DEFPUSHBUTTON or WS_TABSTOP,
        370, 380, 110, 26, hWin,
        HMENU(PtrUInt(IDC_BTN_CLOSE)), HInstance, nil);

      RefreshList(hWin);
    end;

    WM_COMMAND:
    begin
      Cmd := LOWORD(wParam);
      case Cmd of
        IDC_BTN_ADD:
        begin
          FillChar(UrlBuf, SizeOf(UrlBuf), 0);
          FillChar(TtlBuf, SizeOf(TtlBuf), 0);
          GetDlgItemTextW(hWin, IDC_EDIT_URL,
            @UrlBuf[0], Length(UrlBuf));
          GetDlgItemTextW(hWin, IDC_EDIT_TITLE,
            @TtlBuf[0], Length(TtlBuf));
          URL := UnicodeString(PWideChar(@UrlBuf[0]));
          Title := UnicodeString(PWideChar(@TtlBuf[0]));
          if URL = '' then
            MessageBoxW(hWin, 'Please enter a URL.', 'Notice',
              MB_OK or MB_ICONWARNING)
          else begin
            if Title = '' then Title := URL;
            ConfigAddFeed(URL, Title);
            RefreshList(hWin);
            SetDlgItemTextW(hWin, IDC_EDIT_URL, '');
            SetDlgItemTextW(hWin, IDC_EDIT_TITLE, '');
          end;
        end;

        IDC_BTN_REMOVE:
        begin
          hL := GetDlgItem(hWin, IDC_FEED_LIST);
          Sel := SendMessageW(hL, LB_GETCURSEL, 0, 0);
          if (Sel >= 0) and (Sel < Length(GConfig.FeedTitles)) then
          begin
            Title := GConfig.FeedTitles[Sel];
            if MessageBoxW(hWin,
              PWideChar(WideString('Remove "' + Title + '"?')),
              'Remove', MB_YESNO or MB_ICONQUESTION) = IDYES then
            begin
              ConfigRemoveFeed(Title);
              VfsClearFeedCache(Title);
              RefreshList(hWin);
            end;
          end;
        end;

        IDC_BTN_TEST:
        begin
          hL := GetDlgItem(hWin, IDC_FEED_LIST);
          Sel := SendMessageW(hL, LB_GETCURSEL, 0, 0);
          if (Sel >= 0) and (Sel < Length(GConfig.FeedURLs)) then
            DoTestFeed(hWin, GConfig.FeedURLs[Sel])
          else
            MessageBoxW(hWin, 'Please select a feed.', 'Notice',
              MB_OK or MB_ICONWARNING);
        end;

        IDC_BTN_CLOSE:
          DestroyWindow(hWin);

        IDCANCEL:
          DestroyWindow(hWin);
      end;
    end;

    WM_CLOSE:
      DestroyWindow(hWin);

    WM_DESTROY:
    begin
      { Save window position }
      WndRect := Default(TRect);
      GetWindowRect(hWin, WndRect);
      GConfig.RefreshX := WndRect.Left;
      GConfig.RefreshY := WndRect.Top;
      ConfigSave;
      PostQuitMessage(0);
    end;

  else
    Result := DefWindowProcW(hWin, uMsg, wParam, lParam);
  end;
end;

{ ============================================================
  ShowConfigDialog — 1:1 Kopie des GitHubFS-Musters
  ============================================================ }
procedure ShowConfigDialog(hParent: HWND);
var
  WC: TWndClassExW;
  hDlg: HWND;
  Msg: TMsg;
  Cls: WideString;
  PosX, PosY: Integer;
begin
  Cls := 'WFX_RSS_CfgDlg';

  FillChar(WC, SizeOf(WC), 0);
  WC.cbSize        := SizeOf(TWndClassExW);
  WC.style         := CS_HREDRAW or CS_VREDRAW;
  WC.lpfnWndProc   := @CfgWndProc;
  WC.hInstance     := HInstance;
  WC.hbrBackground := HBRUSH(COLOR_BTNFACE + 1);
  WC.lpszClassName := PWideChar(Cls);
  WC.hCursor       := LoadCursor(0, IDC_ARROW);
  RegisterClassExW(WC);

  { Use saved position if valid, otherwise default }
  PosX := GConfig.RefreshX;
  PosY := GConfig.RefreshY;
  if (PosX <= 0) and (PosY <= 0) then
  begin
    PosX := CW_USEDEFAULT;
    PosY := CW_USEDEFAULT;
  end;

  hDlg := CreateWindowExW(
    WS_EX_DLGMODALFRAME or WS_EX_TOPMOST,
    PWideChar(Cls),
    'WFX RSS Reader - Settings',
    WS_OVERLAPPED or WS_CAPTION or WS_SYSMENU,
    PosX, PosY, 500, 445,
    hParent, 0, HInstance, nil);

  if hDlg = 0 then
  begin
    LogError('CreateWindowExW failed: ' +
      UnicodeString(SysErrorMessage(GetLastError)));
    UnregisterClassW(PWideChar(Cls), HInstance);
    Exit;
  end;

  LogMsg('Config dialog created');
  ShowWindow(hDlg, SW_SHOW);
  UpdateWindow(hDlg);
  if hParent <> 0 then
    EnableWindow(hParent, False);

  while GetMessage(Msg, 0, 0, 0) do
  begin
    if not IsDialogMessage(hDlg, Msg) then
    begin
      TranslateMessage(Msg);
      DispatchMessage(Msg);
    end;
  end;

  if hParent <> 0 then
  begin
    EnableWindow(hParent, True);
    SetForegroundWindow(hParent);
  end;
  UnregisterClassW(PWideChar(Cls), HInstance);
  LogMsg('Config dialog closed');
end;

end.
