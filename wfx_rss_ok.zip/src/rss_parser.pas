{ ============================================================
  rss_parser.pas — RSS/XML-Parser (leichtgewichtig)
  Parst RSS 2.0 Feeds ohne externe XML-Bibliothek.
  ============================================================ }
unit rss_parser;

{$MODE ObjFPC}{$H+}

interface

uses
  Windows, SysUtils, rss_types;

function ParseRssFeed(const XmlData: AnsiString;
  const FeedURL: UnicodeString;
  const ContentType: AnsiString;
  out Feed: TRssFeed;
  out ErrMsg: UnicodeString): Boolean;

implementation

uses
  rss_log, rss_charset;

{ --- Hilfs-Funktionen fuer einfaches XML-Parsing --- }

{ Dekodiere HTML/XML-Entities inkl. &#NNN; und &#xNN; }
function DecodeEntities(const S: UnicodeString): UnicodeString;
var
  I, Len: Integer;
  Ch: WideChar;
  P, P2: Integer;
  NumStr: UnicodeString;
  CodePt: Integer;
  IsHex: Boolean;
begin
  if Pos('&', S) = 0 then begin Result := S; Exit; end;

  Result := '';
  Len := Length(S);
  I := 1;
  while I <= Len do
  begin
    Ch := S[I];
    if Ch <> '&' then
    begin
      Result := Result + Ch;
      Inc(I);
      Continue;
    end;

    { Find end of entity }
    P2 := I + 1;
    while (P2 <= Len) and (S[P2] <> ';') and (P2 - I < 12) do
      Inc(P2);

    if (P2 <= Len) and (S[P2] = ';') then
    begin
      NumStr := Copy(S, I + 1, P2 - I - 1);

      { Named entities }
      if NumStr = 'amp'  then begin Result := Result + '&';  I := P2 + 1; Continue; end;
      if NumStr = 'lt'   then begin Result := Result + '<';  I := P2 + 1; Continue; end;
      if NumStr = 'gt'   then begin Result := Result + '>';  I := P2 + 1; Continue; end;
      if NumStr = 'quot' then begin Result := Result + '"';  I := P2 + 1; Continue; end;
      if NumStr = 'apos' then begin Result := Result + ''''; I := P2 + 1; Continue; end;
      if NumStr = 'nbsp' then begin Result := Result + ' ';  I := P2 + 1; Continue; end;

      { Numeric entities: &#NNN; or &#xNNN; }
      if (Length(NumStr) >= 2) and (NumStr[1] = '#') then
      begin
        IsHex := (Length(NumStr) >= 3) and
                 ((NumStr[2] = 'x') or (NumStr[2] = 'X'));
        if IsHex then
          NumStr := Copy(NumStr, 3, MaxInt)
        else
          NumStr := Copy(NumStr, 2, MaxInt);

        CodePt := 0;
        try
          if IsHex then
            CodePt := StrToInt('$' + String(NumStr))
          else
            CodePt := StrToInt(String(NumStr));
        except
          CodePt := 0;
        end;

        if (CodePt > 0) and (CodePt <= $FFFF) then
        begin
          Result := Result + WideChar(CodePt);
          I := P2 + 1;
          Continue;
        end
        else if CodePt > $FFFF then
        begin
          { Supplementary plane: encode as surrogate pair }
          Dec(CodePt, $10000);
          Result := Result +
            WideChar($D800 + (CodePt shr 10)) +
            WideChar($DC00 + (CodePt and $3FF));
          I := P2 + 1;
          Continue;
        end;
      end;
    end;

    { Unknown entity — pass through as-is }
    Result := Result + Ch;
    Inc(I);
  end;
end;

{ Extrahiere Text zwischen <tag> und </tag> (erste Fundstelle) }
function ExtractTagValue(const Xml: UnicodeString;
  const TagName: UnicodeString;
  StartPos: Integer;
  out FoundPos: Integer): UnicodeString;
var
  OpenTag, CloseTag: UnicodeString;
  P1, P2: Integer;
  CDataStart, CDataEnd: Integer;
  Content: UnicodeString;
begin
  Result := '';
  FoundPos := 0;
  OpenTag := '<' + TagName + '>';
  CloseTag := '</' + TagName + '>';

  { Suche auch mit Attributen: <tag ...> }
  P1 := Pos(OpenTag, Xml, StartPos);
  if P1 = 0 then
  begin
    { Versuche mit Attributen }
    P1 := Pos('<' + TagName + ' ', Xml, StartPos);
    if P1 = 0 then
      P1 := Pos('<' + TagName + #9, Xml, StartPos);
    if P1 = 0 then
      Exit;
    { Finde Ende des Opening-Tags }
    P1 := Pos('>', Xml, P1);
    if P1 = 0 then
      Exit;
    Inc(P1); { Hinter das > }
  end
  else
    P1 := P1 + Length(OpenTag);

  P2 := Pos(CloseTag, Xml, P1);
  if P2 = 0 then
    Exit;

  FoundPos := P2 + Length(CloseTag);
  Content := Copy(Xml, P1, P2 - P1);

  { CDATA-Abschnitte behandeln }
  CDataStart := Pos('<![CDATA[', Content);
  if CDataStart > 0 then
  begin
    CDataEnd := Pos(']]>', Content, CDataStart);
    if CDataEnd > 0 then
      Content := Copy(Content, CDataStart + 9,
        CDataEnd - CDataStart - 9);
  end;

  Result := DecodeEntities(Trim(Content));
end;

{ Einfache Version: Extrahiere Tag ohne Positionsrueckgabe }
function GetTagValue(const Xml: UnicodeString;
  const TagName: UnicodeString): UnicodeString;
var
  Dummy: Integer;
begin
  Result := ExtractTagValue(Xml, TagName, 1, Dummy);
end;

{ Finde alle <item>...</item> Bloecke }
type
  TItemBlockArray = array[0..999] of UnicodeString;

procedure SplitItems(const Xml: UnicodeString;
  var Items: TItemBlockArray;
  out Count: Integer);
var
  P, P2: Integer;
  ItemOpen, ItemClose: UnicodeString;
begin
  Count := 0;
  ItemOpen := '<item>';
  ItemClose := '</item>';
  P := 1;

  while True do
  begin
    P := Pos(ItemOpen, Xml, P);
    if P = 0 then
      Break;
    P2 := Pos(ItemClose, Xml, P);
    if P2 = 0 then
      Break;
    if Count <= High(Items) then
    begin
      Items[Count] := Copy(Xml, P + Length(ItemOpen),
        P2 - P - Length(ItemOpen));
      Inc(Count);
    end;
    P := P2 + Length(ItemClose);
  end;
end;

{ ============================================================
  Hauptfunktion: Parse RSS XML
  ============================================================ }
function ParseRssFeed(const XmlData: AnsiString;
  const FeedURL: UnicodeString;
  const ContentType: AnsiString;
  out Feed: TRssFeed;
  out ErrMsg: UnicodeString): Boolean;
var
  Xml: UnicodeString;
  CP: DWORD;
  ItemBlocks: TItemBlockArray;
  ItemCount: Integer;
  I: Integer;
  ItemXml: UnicodeString;
  ChannelStart, ChannelEnd: Integer;
  ChannelXml: UnicodeString;
  DT: TDateTime;
  BaseName: UnicodeString;
  UsedNames: TItemBlockArray;
  UsedCount: Integer;
  CandidateName: UnicodeString;
  NameIdx: Integer;
  NameExists: Boolean;
  J: Integer;
begin
  Result := False;
  ErrMsg := '';
  Feed := Default(TRssFeed);
  Feed.URL := FeedURL;
  UsedCount := 0;

  if Length(XmlData) = 0 then
  begin
    ErrMsg := 'Empty XML data';
    Exit;
  end;

  { Detect encoding and convert directly to UnicodeString via Win API.
    This avoids FPC's UTF8Decode which can produce '?' for non-UTF8 bytes. }
  CP := DetectEncoding(XmlData, ContentType);
  Xml := BodyToUnicode(XmlData, CP);
  LogDetail('Feed encoding: CP=' + IntToStr(CP) +
    ' chars=' + IntToStr(Length(Xml)));
  if Length(Xml) = 0 then
  begin
    ErrMsg := 'Encoding conversion failed';
    Exit;
  end;

  { Pruefen ob RSS vorhanden }
  if (Pos('<rss', Xml) = 0) and (Pos('<feed', Xml) = 0) then
  begin
    ErrMsg := 'Not a valid RSS/Atom document';
    Exit;
  end;

  { Channel-Block extrahieren }
  ChannelStart := Pos('<channel>', Xml);
  if ChannelStart = 0 then
    ChannelStart := Pos('<channel ', Xml);
  ChannelEnd := Pos('</channel>', Xml);

  if (ChannelStart > 0) and (ChannelEnd > 0) then
    ChannelXml := Copy(Xml, ChannelStart,
      ChannelEnd - ChannelStart + 10)
  else
    ChannelXml := Xml;

  { Channel-Metadaten }
  Feed.Title := GetTagValue(ChannelXml, 'title');
  Feed.Link := GetTagValue(ChannelXml, 'link');
  Feed.Description := GetTagValue(ChannelXml, 'description');
  Feed.Language := GetTagValue(ChannelXml, 'language');
  Feed.PubDate := GetTagValue(ChannelXml, 'pubDate');
  Feed.LastBuildDate := GetTagValue(ChannelXml, 'lastBuildDate');
  Feed.ManagingEditor := GetTagValue(ChannelXml, 'managingEditor');

  if Feed.Title = '' then
    Feed.Title := FeedURL;

  { Items extrahieren }
  for I := 0 to High(ItemBlocks) do
    ItemBlocks[I] := '';
  ItemCount := 0;
  SplitItems(ChannelXml, ItemBlocks, ItemCount);

  { Wenn keine Items im Channel, suche in gesamtem Dokument }
  if ItemCount = 0 then
    SplitItems(Xml, ItemBlocks, ItemCount);

  SetLength(Feed.Items, ItemCount);

  for I := 0 to ItemCount - 1 do
  begin
    ItemXml := ItemBlocks[I];
    Feed.Items[I] := Default(TRssFeedItem);

    Feed.Items[I].Title := GetTagValue(ItemXml, 'title');
    Feed.Items[I].Link := GetTagValue(ItemXml, 'link');
    Feed.Items[I].Description := GetTagValue(ItemXml, 'description');
    Feed.Items[I].PubDate := GetTagValue(ItemXml, 'pubDate');
    Feed.Items[I].Author := GetTagValue(ItemXml, 'author');

    { dc:creator als Fallback fuer Author }
    if Feed.Items[I].Author = '' then
      Feed.Items[I].Author := GetTagValue(ItemXml, 'dc:creator');

    Feed.Items[I].Category := GetTagValue(ItemXml, 'category');
    Feed.Items[I].Guid := GetTagValue(ItemXml, 'guid');
    Feed.Items[I].Comments := GetTagValue(ItemXml, 'comments');
    Feed.Items[I].Enclosure := GetTagValue(ItemXml, 'enclosure');
    Feed.Items[I].Source := GetTagValue(ItemXml, 'source');

    { Datum parsen }
    Feed.Items[I].PubDateTime := 0;
    if Feed.Items[I].PubDate <> '' then
    begin
      DT := 0;
      if TryParseRssDate(Feed.Items[I].PubDate, DT) then
        Feed.Items[I].PubDateTime := DT;
    end;

    { Dateiname generieren }
    if Feed.Items[I].Title <> '' then
      BaseName := SanitizeFileName(Feed.Items[I].Title)
    else
      BaseName := 'entry_' + IntToStr(I + 1);

    { Eindeutigkeit sicherstellen }
    CandidateName := BaseName + '.html';
    NameIdx := 2;
    repeat
      NameExists := False;
      for J := 0 to UsedCount - 1 do
      begin
        if CompareText(String(UsedNames[J]),
          String(CandidateName)) = 0 then
        begin
          NameExists := True;
          Break;
        end;
      end;
      if NameExists then
      begin
        CandidateName := BaseName + '_' +
          IntToStr(NameIdx) + '.html';
        Inc(NameIdx);
      end;
    until not NameExists;

    Feed.Items[I].FileName := CandidateName;
    if UsedCount <= High(UsedNames) then
    begin
      UsedNames[UsedCount] := CandidateName;
      Inc(UsedCount);
    end;
  end;

  Feed.LastFetch := Now;
  Feed.CacheValid := True;
  Result := True;

  LogMsg('Feed parsed: ' + Feed.Title + ' — ' +
    IntToStr(ItemCount) + ' entries');
end;

end.
