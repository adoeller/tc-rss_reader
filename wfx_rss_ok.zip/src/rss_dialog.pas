{ ============================================================
  rss_dialog.pas — Config dialog with tabs (Feeds/Proxy/Template)
  Supports system dark mode and custom templates.
  ============================================================ }
unit rss_dialog;

{$MODE ObjFPC}{$H+}

interface

uses
  Windows, SysUtils, rss_types;

procedure ShowConfigDialog(hParent: HWND);

implementation

uses
  Classes, rss_log, rss_config, rss_vfs, rss_http,
  rss_parser, rss_theme;

const
  IDC_FEED_LIST    = 1001;
  IDC_BTN_ADD      = 1010;
  IDC_BTN_REMOVE   = 1011;
  IDC_BTN_TEST     = 1012;
  IDC_EDIT_URL     = 1020;
  IDC_EDIT_TITLE   = 1021;

  IDC_PROXY_TYPE   = 1101;
  IDC_PROXY_SERVER = 1102;
  IDC_PROXY_PORT   = 1103;
  IDC_PROXY_USER   = 1104;
  IDC_PROXY_PASS   = 1105;
  IDC_BTN_PRTEST   = 1106;

  IDC_TPL_LIGHT    = 1201;
  IDC_TPL_DARK     = 1202;

  IDC_TAB          = 1300;
  IDC_BTN_CLOSE    = 1301;
  IDC_LBL_INI      = 1302;
  IDC_CHK_NEWWIN   = 1303;

  TAB_FEEDS = 0;
  TAB_PROXY = 1;
  TAB_TEMPL = 2;

  TCM_INSERTITEMW = $133E;
  TCM_GETCURSEL   = $130B;
  TCM_ADJUSTRECT  = $1328;
  TCN_SELCHANGE   = -551;
  TCIF_TEXT       = $0001;

type
  TTabCItemW = record
    mask: UINT;
    dwState: DWORD;
    dwStateMask: DWORD;
    pszText: PWideChar;
    cchTextMax: Integer;
    iImage: Integer;
    lParam_: LPARAM;
  end;
  PTabCItemW = ^TTabCItemW;

  PNMHdr2 = ^TNMHdr2;
  TNMHdr2 = record
    hwndFrom: HWND;
    idFrom: UINT_PTR;
    code: Integer;
  end;

var
  GTheme: TThemeColors;
  GTabHwnds: array[0..2] of HWND;
  GDPI: Integer;
  GUIFont: HFONT;

procedure ApplyFont(hCtl: HWND);
begin
  if GUIFont <> 0 then
    SendMessageW(hCtl, WM_SETFONT, WPARAM(GUIFont), 1);
end;

procedure CreateUIFont;
type
  TNonClientMetrics = record
    cbSize: UINT;
    iBorderWidth: Integer;
    iScrollWidth: Integer;
    iScrollHeight: Integer;
    iCaptionWidth: Integer;
    iCaptionHeight: Integer;
    lfCaptionFont: LOGFONTW;
    iSmCaptionWidth: Integer;
    iSmCaptionHeight: Integer;
    lfSmCaptionFont: LOGFONTW;
    iMenuWidth: Integer;
    iMenuHeight: Integer;
    lfMenuFont: LOGFONTW;
    lfStatusFont: LOGFONTW;
    lfMessageFont: LOGFONTW;
    iPaddedBorderWidth: Integer;
  end;
var
  NCM: TNonClientMetrics;
begin
  if GUIFont <> 0 then
  begin
    DeleteObject(GUIFont);
    GUIFont := 0;
  end;
  FillChar(NCM, SizeOf(NCM), 0);
  NCM.cbSize := SizeOf(NCM);
  if SystemParametersInfoW(SPI_GETNONCLIENTMETRICS,
    SizeOf(NCM), @NCM, 0) then
    GUIFont := CreateFontIndirectW(NCM.lfMessageFont);
  if GUIFont = 0 then
    GUIFont := HFONT(GetStockObject(DEFAULT_GUI_FONT));
end;

function Sc(V: Integer): Integer;
begin
  if GDPI <= 0 then GDPI := 96;
  Result := MulDiv(V, GDPI, 96);
end;

procedure DetectDPI;
var
  DC: HDC;
begin
  DC := GetDC(0);
  if DC <> 0 then
  begin
    GDPI := GetDeviceCaps(DC, LOGPIXELSX);
    ReleaseDC(0, DC);
  end;
  if GDPI <= 0 then GDPI := 96;
end;

{ Create a control and immediately apply the DPI-aware UI font }
function Ctl(ExStyle: DWORD; const Cls: WideString;
  const Cap: WideString; Style: DWORD;
  X, Y, W, H: Integer; Parent: HWND;
  ID: HMENU): HWND;
begin
  Result := CreateWindowExW(ExStyle, PWideChar(Cls),
    PWideChar(Cap), Style, X, Y, W, H,
    Parent, ID, HInstance, nil);
  ApplyFont(Result);
end;

function GetEditTextU(hCtl: HWND): UnicodeString;
var
  Buf: array[0..2047] of WideChar;
begin
  FillChar(Buf, SizeOf(Buf), 0);
  GetWindowTextW(hCtl, @Buf[0], Length(Buf));
  Result := UnicodeString(PWideChar(@Buf[0]));
end;

function GetDlgItemTextU(hDlg: HWND; ID: Integer): UnicodeString;
var
  hC: HWND;
begin
  hC := GetDlgItem(hDlg, ID);
  if hC = 0 then Result := '' else Result := GetEditTextU(hC);
end;

procedure FeedsRefresh(hPanel: HWND);
var
  hList: HWND;
  I: Integer;
  S: WideString;
begin
  hList := GetDlgItem(hPanel, IDC_FEED_LIST);
  if hList = 0 then Exit;
  ApplyFont(hList);
  SendMessageW(hList, LB_RESETCONTENT, 0, 0);
  for I := 0 to Length(GConfig.FeedTitles)-1 do
  begin
    S := WideString(GConfig.FeedTitles[I]) +
      '  [' + WideString(GConfig.FeedURLs[I]) + ']';
    SendMessageW(hList, LB_ADDSTRING, 0,
      LPARAM(PWideChar(S)));
  end;
end;

procedure TestFeedHttp(hOwner: HWND; const URL: UnicodeString);
var
  Body: AnsiString;
  ErrMsg: UnicodeString;
  Feed: TRssFeed;
  Msg: WideString;
  OldCursor: HCURSOR;
  ContentType: AnsiString;
begin
  Body := '';
  ErrMsg := '';
  ContentType := '';
  Feed := Default(TRssFeed);
  OldCursor := SetCursor(LoadCursor(0, IDC_WAIT));
  try
    if not HttpGet(URL, Body, ContentType, ErrMsg) then
    begin
      SetCursor(OldCursor);
      MessageBoxW(hOwner, PWideChar(WideString('Error: ' + ErrMsg)),
        'Feed Test', MB_OK or MB_ICONERROR or MB_TOPMOST or MB_SETFOREGROUND);
      Exit;
    end;
    if not ParseRssFeed(Body, URL, ContentType, Feed, ErrMsg) then
    begin
      SetCursor(OldCursor);
      MessageBoxW(hOwner, PWideChar(WideString('Parse: ' + ErrMsg)),
        'Feed Test', MB_OK or MB_ICONERROR or MB_TOPMOST or MB_SETFOREGROUND);
      Exit;
    end;
  finally
    SetCursor(OldCursor);
  end;
  Msg := 'OK! ' + WideString(Feed.Title) + ' - ' +
    WideString(IntToStr(Length(Feed.Items))) + ' entries';
  MessageBoxW(hOwner, PWideChar(Msg), 'Feed Test',
    MB_OK or MB_ICONINFORMATION or MB_TOPMOST or MB_SETFOREGROUND);
end;

procedure ProxyLoadToControls(hPanel: HWND);
var
  hCb: HWND;
begin
  hCb := GetDlgItem(hPanel, IDC_PROXY_TYPE);
  SendMessageW(hCb, CB_SETCURSEL,
    WPARAM(GConfig.Proxy.ProxyType), 0);
  SetDlgItemTextW(hPanel, IDC_PROXY_SERVER,
    PWideChar(GConfig.Proxy.Server));
  if GConfig.Proxy.Port > 0 then
    SetDlgItemTextW(hPanel, IDC_PROXY_PORT,
      PWideChar(UnicodeString(IntToStr(GConfig.Proxy.Port))))
  else
    SetDlgItemTextW(hPanel, IDC_PROXY_PORT, '');
  SetDlgItemTextW(hPanel, IDC_PROXY_USER,
    PWideChar(GConfig.Proxy.User));
  SetDlgItemTextW(hPanel, IDC_PROXY_PASS,
    PWideChar(GConfig.Proxy.Password));
end;

procedure ProxySaveFromControls(hPanel: HWND);
var
  hCb: HWND;
  PortStr: UnicodeString;
  TypeIdx: Integer;
begin
  hCb := GetDlgItem(hPanel, IDC_PROXY_TYPE);
  TypeIdx := SendMessageW(hCb, CB_GETCURSEL, 0, 0);
  if TypeIdx < 0 then TypeIdx := 0;
  GConfig.Proxy.ProxyType := TypeIdx;
  GConfig.Proxy.Server :=
    GetDlgItemTextU(hPanel, IDC_PROXY_SERVER);
  PortStr := GetDlgItemTextU(hPanel, IDC_PROXY_PORT);
  GConfig.Proxy.Port := StrToIntDef(String(PortStr), 0);
  GConfig.Proxy.User := GetDlgItemTextU(hPanel, IDC_PROXY_USER);
  GConfig.Proxy.Password :=
    GetDlgItemTextU(hPanel, IDC_PROXY_PASS);
end;

procedure ProxyTestConnection(hOwner, hPanel: HWND);
var
  Saved: TProxyConfig;
  Body: AnsiString;
  ContentType: AnsiString;
  ErrMsg: UnicodeString;
  Msg: WideString;
  OK: Boolean;
  OldCursor: HCURSOR;
begin
  Body := '';
  ContentType := '';
  ErrMsg := '';
  Saved := GConfig.Proxy;
  OldCursor := SetCursor(LoadCursor(0, IDC_WAIT));
  try
    ProxySaveFromControls(hPanel);
    OK := HttpGet('https://www.google.com/', Body, ContentType, ErrMsg);
    SetCursor(OldCursor);
    if OK then
    begin
      Msg := 'Connection OK (' +
        WideString(IntToStr(Length(Body))) + ' bytes)';
      MessageBoxW(hOwner, PWideChar(Msg), 'Proxy Test',
        MB_OK or MB_ICONINFORMATION or MB_TOPMOST or MB_SETFOREGROUND);
    end
    else
    begin
      Msg := 'Failed: ' + WideString(ErrMsg);
      MessageBoxW(hOwner, PWideChar(Msg), 'Proxy Test',
        MB_OK or MB_ICONERROR or MB_TOPMOST or MB_SETFOREGROUND);
    end;
  finally
    SetCursor(OldCursor);
    GConfig.Proxy := Saved;
  end;
end;

procedure TemplateRefresh(hPanel: HWND);
var
  List: TStringList;
  hCb: HWND;
  I, Sel: Integer;
  Name: UnicodeString;
begin
  List := nil;
  ConfigEnumTemplates(List);
  try
    hCb := GetDlgItem(hPanel, IDC_TPL_LIGHT);
    SendMessageW(hCb, CB_RESETCONTENT, 0, 0);
    SendMessageW(hCb, CB_ADDSTRING, 0,
      LPARAM(PWideChar(WideString('(built-in default)'))));
    Sel := 0;
    for I := 0 to List.Count - 1 do
    begin
      Name := UnicodeString(List[I]);
      SendMessageW(hCb, CB_ADDSTRING, 0,
        LPARAM(PWideChar(WideString(Name))));
      if Name = GConfig.TemplateName then Sel := I + 1;
    end;
    SendMessageW(hCb, CB_SETCURSEL, WPARAM(Sel), 0);

    hCb := GetDlgItem(hPanel, IDC_TPL_DARK);
    SendMessageW(hCb, CB_RESETCONTENT, 0, 0);
    SendMessageW(hCb, CB_ADDSTRING, 0,
      LPARAM(PWideChar(WideString('(built-in default)'))));
    Sel := 0;
    for I := 0 to List.Count - 1 do
    begin
      Name := UnicodeString(List[I]);
      SendMessageW(hCb, CB_ADDSTRING, 0,
        LPARAM(PWideChar(WideString(Name))));
      if Name = GConfig.TemplateNameDark then Sel := I + 1;
    end;
    SendMessageW(hCb, CB_SETCURSEL, WPARAM(Sel), 0);
  finally
    List.Free;
  end;
end;

procedure TemplateSaveFromControls(hPanel: HWND);
var
  hCb: HWND;
  Buf: array[0..511] of WideChar;
  S: UnicodeString;
  Idx: Integer;
begin
  hCb := GetDlgItem(hPanel, IDC_TPL_LIGHT);
  Idx := SendMessageW(hCb, CB_GETCURSEL, 0, 0);
  if Idx <= 0 then
    GConfig.TemplateName := 'Default.tmpl'
  else
  begin
    FillChar(Buf, SizeOf(Buf), 0);
    SendMessageW(hCb, CB_GETLBTEXT, WPARAM(Idx), LPARAM(@Buf[0]));
    S := UnicodeString(PWideChar(@Buf[0]));
    GConfig.TemplateName := S;
  end;

  hCb := GetDlgItem(hPanel, IDC_TPL_DARK);
  Idx := SendMessageW(hCb, CB_GETCURSEL, 0, 0);
  if Idx <= 0 then
    GConfig.TemplateNameDark := 'Default.dark.tmpl'
  else
  begin
    FillChar(Buf, SizeOf(Buf), 0);
    SendMessageW(hCb, CB_GETLBTEXT, WPARAM(Idx), LPARAM(@Buf[0]));
    S := UnicodeString(PWideChar(@Buf[0]));
    GConfig.TemplateNameDark := S;
  end;
end;

function PanelWndProc(hWin: HWND; uMsg: UINT;
  wp: WPARAM; lp: LPARAM): LRESULT; stdcall;
var
  R: TRect;
begin
  Result := 0;
  case uMsg of
    WM_COMMAND:
      { Forward button clicks to the main dialog }
      Result := SendMessageW(GetParent(hWin), WM_COMMAND, wp, lp);
    WM_CTLCOLORSTATIC, WM_CTLCOLORBTN:
    begin
      SetTextColor(HDC(wp), GTheme.TextColor);
      SetBkColor(HDC(wp), GTheme.BackColor);
      Result := LRESULT(GTheme.BackBrush);
    end;
    WM_CTLCOLOREDIT, WM_CTLCOLORLISTBOX:
    begin
      SetTextColor(HDC(wp), GTheme.EditTextColor);
      SetBkColor(HDC(wp), GTheme.EditBackColor);
      Result := LRESULT(GTheme.EditBackBrush);
    end;
    WM_ERASEBKGND:
    begin
      GetClientRect(hWin, R);
      FillRect(HDC(wp), R, GTheme.BackBrush);
      Result := 1;
    end;
  else
    Result := DefWindowProcW(hWin, uMsg, wp, lp);
  end;
end;

procedure CreateFeedsPanel(hParent: HWND;
  Left, Top, W, H: Integer);
var
  hPanel: HWND;
  PCls: WideString;
  WC: TWndClassExW;
begin
  PCls := 'WFX_RSS_FeedsPanel';
  UnregisterClassW(PWideChar(PCls), HInstance);
  FillChar(WC, SizeOf(WC), 0);
  WC.cbSize := SizeOf(WC);
  WC.lpfnWndProc := @PanelWndProc;
  WC.hInstance := HInstance;
  WC.hbrBackground := GTheme.BackBrush;
  WC.lpszClassName := PWideChar(PCls);
  WC.hCursor := LoadCursor(0, IDC_ARROW);
  RegisterClassExW(WC);

  hPanel := CreateWindowExW(0, PWideChar(PCls), '',
    WS_CHILD or WS_CLIPCHILDREN,
    Left, Top, W, H, hParent, 0, HInstance, nil);
  GTabHwnds[TAB_FEEDS] := hPanel;

  Ctl(0, 'STATIC', 'Feed URL:',
    WS_CHILD or WS_VISIBLE, Sc(5), Sc(10), Sc(70), Sc(18),
    hPanel, 0);
  Ctl(WS_EX_CLIENTEDGE, 'EDIT', '',
    WS_CHILD or WS_VISIBLE or ES_AUTOHSCROLL or WS_TABSTOP,
    Sc(80), Sc(8), W - Sc(90), Sc(20), hPanel,
    HMENU(PtrUInt(IDC_EDIT_URL)));

  Ctl(0, 'STATIC', 'Title:',
    WS_CHILD or WS_VISIBLE, Sc(5), Sc(36), Sc(70), Sc(18),
    hPanel, 0);
  Ctl(WS_EX_CLIENTEDGE, 'EDIT', '',
    WS_CHILD or WS_VISIBLE or ES_AUTOHSCROLL or WS_TABSTOP,
    Sc(80), Sc(34), W - Sc(90), Sc(20), hPanel,
    HMENU(PtrUInt(IDC_EDIT_TITLE)));

  { Cue banner: hint text shown when field is empty }
  SendMessageW(GetDlgItem(hPanel, IDC_EDIT_TITLE),
    $1501 {EM_SETCUEBANNER}, 1,
    LPARAM(PWideChar(WideString(
      '(optional - fetched from feed if empty)'))));
  SendMessageW(GetDlgItem(hPanel, IDC_EDIT_URL),
    $1501 {EM_SETCUEBANNER}, 1,
    LPARAM(PWideChar(WideString('https://...'))));

  Ctl(0, 'BUTTON', 'Add',
    WS_CHILD or WS_VISIBLE or WS_TABSTOP,
    Sc(5), Sc(62), Sc(110), Sc(26), hPanel,
    HMENU(PtrUInt(IDC_BTN_ADD)));
  Ctl(0, 'BUTTON', 'Remove',
    WS_CHILD or WS_VISIBLE or WS_TABSTOP,
    Sc(120), Sc(62), Sc(110), Sc(26), hPanel,
    HMENU(PtrUInt(IDC_BTN_REMOVE)));
  Ctl(0, 'BUTTON', 'Test',
    WS_CHILD or WS_VISIBLE or WS_TABSTOP,
    Sc(235), Sc(62), Sc(110), Sc(26), hPanel,
    HMENU(PtrUInt(IDC_BTN_TEST)));

  Ctl(WS_EX_CLIENTEDGE, 'LISTBOX', '',
    WS_CHILD or WS_VISIBLE or WS_VSCROLL or WS_TABSTOP or
    LBS_NOTIFY or LBS_NOINTEGRALHEIGHT,
    Sc(5), Sc(96), W - Sc(10), H - Sc(105), hPanel,
    HMENU(PtrUInt(IDC_FEED_LIST)));

  FeedsRefresh(hPanel);
end;

procedure CreateProxyPanel(hParent: HWND;
  Left, Top, W, H: Integer);
var
  hPanel, hCb: HWND;
  PCls: WideString;
  WC: TWndClassExW;
begin
  PCls := 'WFX_RSS_ProxyPanel';
  UnregisterClassW(PWideChar(PCls), HInstance);
  FillChar(WC, SizeOf(WC), 0);
  WC.cbSize := SizeOf(WC);
  WC.lpfnWndProc := @PanelWndProc;
  WC.hInstance := HInstance;
  WC.hbrBackground := GTheme.BackBrush;
  WC.lpszClassName := PWideChar(PCls);
  WC.hCursor := LoadCursor(0, IDC_ARROW);
  RegisterClassExW(WC);

  hPanel := CreateWindowExW(0, PWideChar(PCls), '',
    WS_CHILD or WS_CLIPCHILDREN,
    Left, Top, W, H, hParent, 0, HInstance, nil);
  GTabHwnds[TAB_PROXY] := hPanel;

  Ctl(0, 'STATIC', 'Type:',
    WS_CHILD or WS_VISIBLE, Sc(5), Sc(12), Sc(70), Sc(18),
    hPanel, 0);
  hCb := Ctl(0, 'COMBOBOX', '',
    WS_CHILD or WS_VISIBLE or WS_TABSTOP or
    CBS_DROPDOWNLIST or WS_VSCROLL,
    Sc(80), Sc(8), Sc(200), Sc(200), hPanel,
    HMENU(PtrUInt(IDC_PROXY_TYPE)));
  SendMessageW(hCb, CB_ADDSTRING, 0,
    LPARAM(PWideChar(WideString('System (default)'))));
  SendMessageW(hCb, CB_ADDSTRING, 0,
    LPARAM(PWideChar(WideString('HTTP proxy'))));
  SendMessageW(hCb, CB_ADDSTRING, 0,
    LPARAM(PWideChar(WideString('SOCKS5 proxy'))));
  SendMessageW(hCb, CB_ADDSTRING, 0,
    LPARAM(PWideChar(WideString('Direct (no proxy)'))));

  Ctl(0, 'STATIC', 'Server:',
    WS_CHILD or WS_VISIBLE, Sc(5), Sc(42), Sc(70), Sc(18),
    hPanel, 0);
  Ctl(WS_EX_CLIENTEDGE, 'EDIT', '',
    WS_CHILD or WS_VISIBLE or ES_AUTOHSCROLL or WS_TABSTOP,
    Sc(80), Sc(40), Sc(250), Sc(20), hPanel,
    HMENU(PtrUInt(IDC_PROXY_SERVER)));

  Ctl(0, 'STATIC', 'Port:',
    WS_CHILD or WS_VISIBLE, Sc(340), Sc(42), Sc(35), Sc(18),
    hPanel, 0);
  Ctl(WS_EX_CLIENTEDGE, 'EDIT', '',
    WS_CHILD or WS_VISIBLE or ES_AUTOHSCROLL or
    ES_NUMBER or WS_TABSTOP,
    Sc(380), Sc(40), Sc(80), Sc(20), hPanel,
    HMENU(PtrUInt(IDC_PROXY_PORT)));

  Ctl(0, 'STATIC', 'User:',
    WS_CHILD or WS_VISIBLE, Sc(5), Sc(72), Sc(70), Sc(18),
    hPanel, 0);
  Ctl(WS_EX_CLIENTEDGE, 'EDIT', '',
    WS_CHILD or WS_VISIBLE or ES_AUTOHSCROLL or WS_TABSTOP,
    Sc(80), Sc(70), Sc(250), Sc(20), hPanel,
    HMENU(PtrUInt(IDC_PROXY_USER)));

  Ctl(0, 'STATIC', 'Password:',
    WS_CHILD or WS_VISIBLE, Sc(5), Sc(102), Sc(70), Sc(18),
    hPanel, 0);
  Ctl(WS_EX_CLIENTEDGE, 'EDIT', '',
    WS_CHILD or WS_VISIBLE or ES_AUTOHSCROLL or
    ES_PASSWORD or WS_TABSTOP,
    Sc(80), Sc(100), Sc(250), Sc(20), hPanel,
    HMENU(PtrUInt(IDC_PROXY_PASS)));

  Ctl(0, 'BUTTON', 'Test connection',
    WS_CHILD or WS_VISIBLE or WS_TABSTOP,
    Sc(80), Sc(135), Sc(150), Sc(26), hPanel,
    HMENU(PtrUInt(IDC_BTN_PRTEST)));

  ProxyLoadToControls(hPanel);
end;

procedure CreateTemplatePanel(hParent: HWND;
  Left, Top, W, H: Integer);
var
  hPanel: HWND;
  PCls: WideString;
  WC: TWndClassExW;
begin
  PCls := 'WFX_RSS_TemplPanel';
  UnregisterClassW(PWideChar(PCls), HInstance);
  FillChar(WC, SizeOf(WC), 0);
  WC.cbSize := SizeOf(WC);
  WC.lpfnWndProc := @PanelWndProc;
  WC.hInstance := HInstance;
  WC.hbrBackground := GTheme.BackBrush;
  WC.lpszClassName := PWideChar(PCls);
  WC.hCursor := LoadCursor(0, IDC_ARROW);
  RegisterClassExW(WC);

  hPanel := CreateWindowExW(0, PWideChar(PCls), '',
    WS_CHILD or WS_CLIPCHILDREN,
    Left, Top, W, H, hParent, 0, HInstance, nil);
  GTabHwnds[TAB_TEMPL] := hPanel;

  Ctl(0, 'STATIC', 'Light theme:',
    WS_CHILD or WS_VISIBLE, Sc(5), Sc(12), Sc(95), Sc(18),
    hPanel, 0);
  Ctl(0, 'COMBOBOX', '',
    WS_CHILD or WS_VISIBLE or WS_TABSTOP or
    CBS_DROPDOWNLIST or WS_VSCROLL,
    Sc(105), Sc(8), Sc(300), Sc(200), hPanel,
    HMENU(PtrUInt(IDC_TPL_LIGHT)));

  Ctl(0, 'STATIC', 'Dark theme:',
    WS_CHILD or WS_VISIBLE, Sc(5), Sc(42), Sc(95), Sc(18),
    hPanel, 0);
  Ctl(0, 'COMBOBOX', '',
    WS_CHILD or WS_VISIBLE or WS_TABSTOP or
    CBS_DROPDOWNLIST or WS_VSCROLL,
    Sc(105), Sc(38), Sc(300), Sc(200), hPanel,
    HMENU(PtrUInt(IDC_TPL_DARK)));

  Ctl(0, 'STATIC',
    'Templates are *.tmpl files in the plugin folder.' + #13#10 +
    'Active theme follows Windows light/dark setting.',
    WS_CHILD or WS_VISIBLE,
    Sc(5), Sc(80), W - Sc(10), Sc(50),
    hPanel, 0);

  TemplateRefresh(hPanel);
end;

procedure InsertTab(hTab: HWND; Idx: Integer; const Caption: WideString);
var
  TI: TTabCItemW;
  P: Pointer;
begin
  FillChar(TI, SizeOf(TI), 0);
  TI.mask := TCIF_TEXT;
  TI.pszText := PWideChar(Caption);
  P := @TI;
  SendMessageW(hTab, TCM_INSERTITEMW, WPARAM(Idx), LPARAM(P));
end;

function CfgWndProc(hWin: HWND; uMsg: UINT;
  wp: WPARAM; lp: LPARAM): LRESULT; stdcall;
var
  Cmd, NewTab: Integer;
  URL, Title: UnicodeString;
  Sel: Integer;
  hL: HWND;
  WndRect, TabRect: TRect;
  hTab: HWND;
  PageL, PageT, PageW, PageH: Integer;
  NMH: PNMHdr2;
  I: Integer;
  PRect: Pointer;
  OldCursor: HCURSOR;
  FetchBody: AnsiString;
  FetchContentType: AnsiString;
  FetchErr: UnicodeString;
  FetchFeed: TRssFeed;
begin
  Result := 0;
  case uMsg of

    WM_CREATE:
    begin
      GetClientRect(hWin, WndRect);
      hTab := CreateWindowExW(0, 'SysTabControl32', '',
        WS_CHILD or WS_VISIBLE or WS_TABSTOP,
        Sc(10), Sc(10),
        WndRect.Right - Sc(20),
        WndRect.Bottom - Sc(75),
        hWin, HMENU(PtrUInt(IDC_TAB)), HInstance, nil);
      ApplyFont(hTab);

      InsertTab(hTab, 0, 'Feeds');
      InsertTab(hTab, 1, 'Proxy');
      InsertTab(hTab, 2, 'Template');

      GetWindowRect(hTab, TabRect);
      MapWindowPoints(0, hWin, @TabRect, 2);
      PRect := @TabRect;
      SendMessageW(hTab, TCM_ADJUSTRECT, 0, LPARAM(PRect));
      PageL := TabRect.Left;
      PageT := TabRect.Top;
      PageW := TabRect.Right - TabRect.Left;
      PageH := TabRect.Bottom - TabRect.Top;

      CreateFeedsPanel(hWin, PageL, PageT, PageW, PageH);
      CreateProxyPanel(hWin, PageL, PageT, PageW, PageH);
      CreateTemplatePanel(hWin, PageL, PageT, PageW, PageH);

      ShowWindow(GTabHwnds[0], SW_SHOW);
      ShowWindow(GTabHwnds[1], SW_HIDE);
      ShowWindow(GTabHwnds[2], SW_HIDE);

      Ctl(0, 'BUTTON', 'Open links in new window',
        WS_CHILD or WS_VISIBLE or BS_AUTOCHECKBOX or WS_TABSTOP,
        Sc(10), WndRect.Bottom - Sc(62),
        WndRect.Right - Sc(160), Sc(22),
        hWin, HMENU(PtrUInt(IDC_CHK_NEWWIN)));

      Ctl(0, 'STATIC',
        WideString('INI: ' + GConfig.IniPath),
        WS_CHILD or WS_VISIBLE,
        Sc(10), WndRect.Bottom - Sc(36),
        WndRect.Right - Sc(140), Sc(18),
        hWin, HMENU(PtrUInt(IDC_LBL_INI)));

      Ctl(0, 'BUTTON', 'Close',
        WS_CHILD or WS_VISIBLE or BS_DEFPUSHBUTTON or WS_TABSTOP,
        WndRect.Right - Sc(130), WndRect.Bottom - Sc(36),
        Sc(120), Sc(26),
        hWin, HMENU(PtrUInt(IDC_BTN_CLOSE)));

      { Set checkbox state from config }
      if GConfig.OpenLinksNewWindow then
        SendMessageW(GetDlgItem(hWin, IDC_CHK_NEWWIN),
          BM_SETCHECK, BST_CHECKED, 0);
    end;

    WM_CTLCOLORDLG, WM_CTLCOLORSTATIC, WM_CTLCOLORBTN:
    begin
      SetTextColor(HDC(wp), GTheme.TextColor);
      SetBkColor(HDC(wp), GTheme.BackColor);
      Result := LRESULT(GTheme.BackBrush);
    end;
    WM_CTLCOLOREDIT, WM_CTLCOLORLISTBOX:
    begin
      SetTextColor(HDC(wp), GTheme.EditTextColor);
      SetBkColor(HDC(wp), GTheme.EditBackColor);
      Result := LRESULT(GTheme.EditBackBrush);
    end;

    WM_NOTIFY:
    begin
      NMH := PNMHdr2(lp);
      if (NMH^.idFrom = IDC_TAB) and
        (NMH^.code = TCN_SELCHANGE) then
      begin
        hTab := GetDlgItem(hWin, IDC_TAB);
        NewTab := SendMessageW(hTab, TCM_GETCURSEL, 0, 0);
        for I := 0 to 2 do
          if I = NewTab then
            ShowWindow(GTabHwnds[I], SW_SHOW)
          else
            ShowWindow(GTabHwnds[I], SW_HIDE);
      end;
    end;

    WM_COMMAND:
    begin
      Cmd := LOWORD(wp);
      case Cmd of
        IDC_BTN_CLOSE, IDCANCEL:
          DestroyWindow(hWin);

        IDC_BTN_ADD:
        begin
          URL := GetDlgItemTextU(GTabHwnds[TAB_FEEDS], IDC_EDIT_URL);
          Title := GetDlgItemTextU(GTabHwnds[TAB_FEEDS], IDC_EDIT_TITLE);
          if URL = '' then
            MessageBoxW(hWin, 'Please enter a URL.',
              'Notice', MB_OK or MB_ICONWARNING or MB_TOPMOST or MB_SETFOREGROUND)
          else
          begin
            if Title = '' then
            begin
              { Fetch title from feed }
              OldCursor := SetCursor(LoadCursor(0, IDC_WAIT));
              FetchBody := '';
              FetchErr := '';
              FetchFeed := Default(TRssFeed);
              if HttpGet(URL, FetchBody, FetchContentType, FetchErr) and
                ParseRssFeed(FetchBody, URL, FetchContentType, FetchFeed,
                  FetchErr) and (FetchFeed.Title <> '') then
                Title := FetchFeed.Title
              else
                Title := URL;
              SetCursor(OldCursor);
            end;
            ConfigAddFeed(URL, Title);
            FeedsRefresh(GTabHwnds[TAB_FEEDS]);
            SetDlgItemTextW(GTabHwnds[TAB_FEEDS], IDC_EDIT_URL, '');
            SetDlgItemTextW(GTabHwnds[TAB_FEEDS], IDC_EDIT_TITLE, '');
          end;
        end;

        IDC_BTN_REMOVE:
        begin
          hL := GetDlgItem(GTabHwnds[TAB_FEEDS], IDC_FEED_LIST);
          Sel := SendMessageW(hL, LB_GETCURSEL, 0, 0);
          if (Sel >= 0) and (Sel < Length(GConfig.FeedTitles)) then
          begin
            Title := GConfig.FeedTitles[Sel];
            if MessageBoxW(hWin,
              PWideChar(WideString('Remove "' + Title + '"?')),
              'Remove', MB_YESNO or MB_ICONQUESTION or MB_TOPMOST or MB_SETFOREGROUND) = IDYES then
            begin
              ConfigRemoveFeed(Title);
              VfsClearFeedCache(Title);
              FeedsRefresh(GTabHwnds[TAB_FEEDS]);
            end;
          end;
        end;

        IDC_BTN_TEST:
        begin
          hL := GetDlgItem(GTabHwnds[TAB_FEEDS], IDC_FEED_LIST);
          Sel := SendMessageW(hL, LB_GETCURSEL, 0, 0);
          if (Sel >= 0) and (Sel < Length(GConfig.FeedURLs)) then
            TestFeedHttp(hWin, GConfig.FeedURLs[Sel])
          else
            MessageBoxW(hWin, 'Please select a feed.',
              'Notice', MB_OK or MB_ICONWARNING or MB_TOPMOST or MB_SETFOREGROUND);
        end;

        IDC_BTN_PRTEST:
          ProxyTestConnection(hWin, GTabHwnds[TAB_PROXY]);
      end;
    end;

    WM_CLOSE:
      DestroyWindow(hWin);

    WM_DESTROY:
    begin
      ProxySaveFromControls(GTabHwnds[TAB_PROXY]);
      TemplateSaveFromControls(GTabHwnds[TAB_TEMPL]);
      GConfig.OpenLinksNewWindow :=
        SendMessageW(GetDlgItem(hWin, IDC_CHK_NEWWIN),
          BM_GETCHECK, 0, 0) = BST_CHECKED;
      ConfigLoadTemplate;
      WndRect := Default(TRect);
      GetWindowRect(hWin, WndRect);
      GConfig.RefreshX := WndRect.Left;
      GConfig.RefreshY := WndRect.Top;
      ConfigSave;
      PostQuitMessage(0);
    end;

  else
    Result := DefWindowProcW(hWin, uMsg, wp, lp);
  end;
end;

procedure ShowConfigDialog(hParent: HWND);
var
  WC: TWndClassExW;
  hDlg: HWND;
  Msg: TMsg;
  Cls: WideString;
  PosX, PosY: Integer;
begin
  DetectDPI;
  CreateUIFont;
  InitThemeColors(GTheme, IsSystemDarkMode);

  Cls := 'WFX_RSS_CfgDlg';
  UnregisterClassW(PWideChar(Cls), HInstance);

  FillChar(WC, SizeOf(WC), 0);
  WC.cbSize        := SizeOf(TWndClassExW);
  WC.style         := CS_HREDRAW or CS_VREDRAW;
  WC.lpfnWndProc   := @CfgWndProc;
  WC.hInstance     := HInstance;
  WC.hbrBackground := GTheme.BackBrush;
  WC.lpszClassName := PWideChar(Cls);
  WC.hCursor       := LoadCursor(0, IDC_ARROW);
  RegisterClassExW(WC);

  PosX := GConfig.RefreshX;
  PosY := GConfig.RefreshY;
  if (PosX <= 0) and (PosY <= 0) then
  begin
    PosX := CW_USEDEFAULT;
    PosY := CW_USEDEFAULT;
  end;

  hDlg := CreateWindowExW(
    WS_EX_DLGMODALFRAME or WS_EX_TOPMOST,
    PWideChar(Cls),
    'WFX RSS Reader - Settings',
    WS_OVERLAPPED or WS_CAPTION or WS_SYSMENU,
    PosX, PosY, Sc(540), Sc(480),
    hParent, 0, HInstance, nil);

  if hDlg = 0 then
  begin
    UnregisterClassW(PWideChar(Cls), HInstance);
    FreeThemeColors(GTheme);
    Exit;
  end;

  ShowWindow(hDlg, SW_SHOW);
  UpdateWindow(hDlg);
  if hParent <> 0 then
    EnableWindow(hParent, False);

  while GetMessage(Msg, 0, 0, 0) do
  begin
    if not IsDialogMessage(hDlg, Msg) then
    begin
      TranslateMessage(Msg);
      DispatchMessage(Msg);
    end;
  end;

  if hParent <> 0 then
  begin
    EnableWindow(hParent, True);
    SetForegroundWindow(hParent);
  end;
  UnregisterClassW(PWideChar(Cls), HInstance);
  FreeThemeColors(GTheme);
  if GUIFont <> 0 then
  begin
    DeleteObject(GUIFont);
    GUIFont := 0;
  end;
end;

end.
