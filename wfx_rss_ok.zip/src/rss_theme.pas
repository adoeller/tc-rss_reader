{ ============================================================
  rss_theme.pas — Dark mode detection and color scheme
  ============================================================ }
unit rss_theme;

{$MODE ObjFPC}{$H+}

interface

uses
  Windows, SysUtils;

type
  TThemeColors = record
    BackBrush: HBRUSH;
    BackColor: COLORREF;
    TextColor: COLORREF;
    EditBackBrush: HBRUSH;
    EditBackColor: COLORREF;
    EditTextColor: COLORREF;
    BorderColor: COLORREF;
  end;

function IsSystemDarkMode: Boolean;
procedure InitThemeColors(out T: TThemeColors; DarkMode: Boolean);
procedure FreeThemeColors(var T: TThemeColors);

implementation

function IsSystemDarkMode: Boolean;
var
  hKey: HANDLE;
  Data: DWORD;
  Sz: DWORD;
  ValueType: DWORD;
begin
  Result := False;
  if RegOpenKeyExW(HKEY_CURRENT_USER,
    'Software\Microsoft\Windows\CurrentVersion\Themes\Personalize',
    0, KEY_READ, @hKey) <> ERROR_SUCCESS then
    Exit;
  try
    Data := 1;
    Sz := SizeOf(Data);
    ValueType := REG_DWORD;
    if RegQueryValueExW(hKey, 'AppsUseLightTheme',
      nil, @ValueType, @Data, @Sz) = ERROR_SUCCESS then
      Result := (Data = 0);
  finally
    RegCloseKey(hKey);
  end;
end;

procedure InitThemeColors(out T: TThemeColors; DarkMode: Boolean);
begin
  if DarkMode then
  begin
    T.BackColor := $002D2D2D;
    T.TextColor := $00E0E0E0;
    T.EditBackColor := $003C3C3C;
    T.EditTextColor := $00E0E0E0;
    T.BorderColor := $00505050;
  end
  else
  begin
    T.BackColor := GetSysColor(COLOR_BTNFACE);
    T.TextColor := GetSysColor(COLOR_BTNTEXT);
    T.EditBackColor := GetSysColor(COLOR_WINDOW);
    T.EditTextColor := GetSysColor(COLOR_WINDOWTEXT);
    T.BorderColor := GetSysColor(COLOR_WINDOWFRAME);
  end;
  T.BackBrush := CreateSolidBrush(T.BackColor);
  T.EditBackBrush := CreateSolidBrush(T.EditBackColor);
end;

procedure FreeThemeColors(var T: TThemeColors);
begin
  if T.BackBrush <> 0 then
  begin
    DeleteObject(T.BackBrush);
    T.BackBrush := 0;
  end;
  if T.EditBackBrush <> 0 then
  begin
    DeleteObject(T.EditBackBrush);
    T.EditBackBrush := 0;
  end;
end;

end.
