{$MODE ObjFPC}{$H+}
unit rss_template;

interface

uses
  Windows, SysUtils, rss_types;

function RenderItem(const Template: UnicodeString;
  const Item: TRssFeedItem): UnicodeString;

implementation

uses
  rss_config;

{ Add target="_blank" to all <a href=...> links that don't already have it }
function InjectTargetBlank(const Html: UnicodeString): UnicodeString;
var
  I, Len: Integer;
  Lower: UnicodeString;
  TagStart, TagEnd: Integer;
  Tag, TagLow: UnicodeString;
begin
  Result := '';
  Len := Length(Html);
  Lower := LowerCase(Html);
  I := 1;
  while I <= Len do
  begin
    { Find next <a (case-insensitive) }
    TagStart := I;
    if (I <= Len - 1) and (Lower[I] = '<') and
       (Lower[I + 1] = 'a') and
       ((I + 2 > Len) or (Lower[I + 2] = ' ') or
        (Lower[I + 2] = #9) or (Lower[I + 2] = '>')) then
    begin
      { Find end of this tag }
      TagEnd := I + 1;
      while (TagEnd <= Len) and (Html[TagEnd] <> '>') do
        Inc(TagEnd);
      if TagEnd > Len then
      begin
        Result := Result + Copy(Html, I, Len - I + 1);
        Break;
      end;
      Tag := Copy(Html, I, TagEnd - I + 1);
      TagLow := LowerCase(Tag);
      { Only inject if it has href and no target yet }
      if (Pos('href', TagLow) > 0) and
         (Pos('target', TagLow) = 0) then
      begin
        { Insert target="_blank" before closing > }
        Tag := Copy(Tag, 1, Length(Tag) - 1) +
          ' target="_blank">';
      end;
      Result := Result + Tag;
      I := TagEnd + 1;
    end
    else
    begin
      Result := Result + Html[I];
      Inc(I);
    end;
  end;
end;

{ Encode all non-ASCII chars to &#NNN; entities.
  Used for plain-text fields (title, author etc.) }
function HtmlEncode(const S: UnicodeString): UnicodeString;
var
  I: Integer;
  Ch: WideChar;
  W: Word;
begin
  Result := '';
  for I := 1 to Length(S) do
  begin
    Ch := S[I];
    case Ch of
      '&': Result := Result + '&amp;';
      '<': Result := Result + '&lt;';
      '>': Result := Result + '&gt;';
      '"': Result := Result + '&quot;';
    else
      W := Word(Ch);
      if W > 127 then
        Result := Result + '&#' + IntToStr(W) + ';'
      else
        Result := Result + Ch;
    end;
  end;
end;

{ Encode non-ASCII chars to &#NNN; but keep HTML tags and
  existing &entities; intact. Used for description (contains HTML). }
function HtmlEncodeKeepTags(const S: UnicodeString): UnicodeString;
var
  I, Len: Integer;
  Ch: WideChar;
  W: Word;
  InTag: Boolean;
  InEntity: Boolean;
  EntityLen: Integer;
begin
  Result := '';
  Len := Length(S);
  I := 1;
  InTag := False;
  InEntity := False;
  EntityLen := 0;
  while I <= Len do
  begin
    Ch := S[I];

    { Inside HTML tag: pass through unchanged }
    if InTag then
    begin
      Result := Result + Ch;
      if Ch = '>' then
        InTag := False;
      Inc(I);
      Continue;
    end;

    { Start of HTML tag }
    if Ch = '<' then
    begin
      InTag := True;
      Result := Result + Ch;
      Inc(I);
      Continue;
    end;

    { Inside &entity; : pass through unchanged }
    if InEntity then
    begin
      Result := Result + Ch;
      Inc(EntityLen);
      if (Ch = ';') or (EntityLen > 10) then
        InEntity := False;
      Inc(I);
      Continue;
    end;

    { Start of &entity; }
    if Ch = '&' then
    begin
      InEntity := True;
      EntityLen := 0;
      Result := Result + Ch;
      Inc(I);
      Continue;
    end;

    { Normal text: encode non-ASCII }
    W := Word(Ch);
    if W > 127 then
      Result := Result + '&#' + IntToStr(W) + ';'
    else
      Result := Result + Ch;

    Inc(I);
  end;
end;

function RenderItem(const Template: UnicodeString;
  const Item: TRssFeedItem): UnicodeString;
var
  R: UnicodeString;
begin
  R := Template;
  R := StringReplace(R, '<%title%>',
    HtmlEncode(Item.Title), [rfReplaceAll]);
  R := StringReplace(R, '<%link%>',
    HtmlEncode(Item.Link), [rfReplaceAll]);
  { Description contains HTML — encode only non-ASCII chars,
    preserve tags and entities }
  R := StringReplace(R, '<%description%>',
    HtmlEncodeKeepTags(Item.Description), [rfReplaceAll]);
  R := StringReplace(R, '<%pubDate%>',
    HtmlEncode(Item.PubDate), [rfReplaceAll]);
  R := StringReplace(R, '<%author%>',
    HtmlEncode(Item.Author), [rfReplaceAll]);
  R := StringReplace(R, '<%category%>',
    HtmlEncode(Item.Category), [rfReplaceAll]);
  R := StringReplace(R, '<%guid%>',
    HtmlEncode(Item.Guid), [rfReplaceAll]);
  R := StringReplace(R, '<%comments%>',
    HtmlEncode(Item.Comments), [rfReplaceAll]);
  R := StringReplace(R, '<%enclosure%>',
    HtmlEncode(Item.Enclosure), [rfReplaceAll]);
  R := StringReplace(R, '<%source%>',
    HtmlEncode(Item.Source), [rfReplaceAll]);

  { Charset-Meta erzwingen wenn nicht vorhanden }
  if Pos('charset', LowerCase(R)) = 0 then
  begin
    if Pos('<head>', LowerCase(R)) > 0 then
      R := StringReplace(R, '<head>', '<head>'#13#10 +
        '<meta charset="utf-8">', [rfIgnoreCase])
    else if Pos('<html>', LowerCase(R)) > 0 then
      R := StringReplace(R, '<html>', '<html><head>' +
        '<meta charset="utf-8"></head>', [rfIgnoreCase])
    else
      R := '<html><head><meta charset="utf-8"></head>' +
        #13#10 + R;
  end;

  { Inject target="_blank" on all links if setting active }
  if GConfig.OpenLinksNewWindow then
    R := InjectTargetBlank(R);

  Result := R;
end;

end.
