{ ============================================================
  wfx_rss.lpr — WFX RSS Reader Plugin fuer Total Commander
  64-bit Unicode, Free Pascal / Lazarus
  ============================================================ }
library wfx_rss;

{$MODE ObjFPC}{$H+}

uses
  Windows, SysUtils,
  fsplugin,
  rss_types,
  rss_log,
  rss_config,
  rss_http,
  rss_parser,
  rss_template,
  rss_vfs,
  rss_dialog;

{ ShellExecuteW — direkt deklariert, kein ShellApi-Import noetig }
function ShellExecuteW(hWin: HWND; lpOperation: PWideChar;
  lpFile: PWideChar; lpParameters: PWideChar;
  lpDirectory: PWideChar; nShowCmd: Integer): HINST;
  stdcall; external 'shell32.dll' name 'ShellExecuteW';

{ ============================================================
  ANSI Stubs (Pflicht — TC prueft diese beim Laden)
  ============================================================ }

function FsInit(PluginNr: Integer; pProgressProc: TProgressProc;
  pLogProc: TLogProc;
  pRequestProc: TRequestProc): Integer; stdcall;
begin
  GPluginNr := PluginNr;
  GProgressCb := pProgressProc;
  GLogCb := pLogProc;
  GRequestCb := pRequestProc;
  Result := 0;
end;

function FsFindFirst(Path: PAnsiChar;
  var FindData: TWin32FindData): THandle; stdcall;
begin
  FindData := Default(TWin32FindData);
  Result := INVALID_HANDLE_VALUE;
end;

function FsFindNext(Hdl: THandle;
  var FindData: TWin32FindData): BOOL; stdcall;
begin
  Result := False;
end;

{ ============================================================
  Unicode-Implementierungen
  ============================================================ }

function FsInitW(PluginNr: Integer;
  pProgressProcW: TProgressProcW;
  pLogProcW: TLogProcW;
  pRequestProcW: TRequestProcW): Integer; stdcall;
begin
  GPluginNr := PluginNr;
  GProgressCbW := pProgressProcW;
  GLogCbW := pLogProcW;
  GRequestCbW := pRequestProcW;
  VfsInit;
  Result := 0;
end;

function FsFindFirstW(Path: PWideChar;
  var FindData: TWin32FindDataW): THandle; stdcall;
var
  PathStr: UnicodeString;
begin
  PathStr := UnicodeString(Path);
  Result := VfsFindFirst(PathStr, FindData);
end;

function FsFindNextW(Hdl: THandle;
  var FindData: TWin32FindDataW): BOOL; stdcall;
begin
  if VfsFindNext(Hdl, FindData) then
    Result := True
  else
    Result := False;
end;

procedure FsFindClose(Hdl: THandle); stdcall;
begin
  VfsFindClose(Hdl);
end;

{ ============================================================
  Plugin-Metadaten
  ============================================================ }

procedure FsGetDefRootName(DefRootName: PAnsiChar;
  MaxLen: Integer); stdcall;
const
  PluginName: AnsiString = 'RSS Reader';
var
  Len: Integer;
begin
  Len := Length(PluginName);
  if Len >= MaxLen then
    Len := MaxLen - 1;
  Move(PluginName[1], DefRootName^, Len);
  DefRootName[Len] := #0;
end;

procedure FsSetDefaultParams(
  var dps: TFsDefaultParamStruct); stdcall;
var
  IniDir: UnicodeString;
begin
  ConfigInit(dps.DefaultIniName);
  IniDir := ExtractFilePath(GConfig.IniPath);
  LogInit(IniDir);
  LogMsg('Plugin initialized, version 1.0');
  LogMsg('INI-Pfad: ' + GConfig.IniPath);
  ConfigLoad;
  LogMsg('Feeds loaded: ' + IntToStr(Length(GConfig.FeedTitles)));
end;

function FsLinksToLocalFiles: BOOL; stdcall;
begin
  Result := False;
end;

{ ============================================================
  FsExecuteFileW — Hauptlogik fuer Doppelklick und Alt+Enter

  TC ruft diese Funktion auf wenn:
  - User Doppelklick auf Datei/Ordner macht (Verb="open")
  - User Alt+Enter drueckt (Verb="properties")

  Rueckgabewerte:
  - FS_EXEC_OK      = Plugin hat es erledigt, TC bleibt
  - FS_EXEC_SYMLINK = TC navigiert zu RemoteName
  - FS_EXEC_ERROR   = Fehler
  ============================================================ }

function FsExecuteFileW(MainWin: HWND; RemoteName: PWideChar;
  Verb: PAnsiChar): Integer; stdcall;
var
  VerbStr: UnicodeString;
  PathStr: UnicodeString;
  PI: TPathInfo;
  Content: AnsiString;
  ErrMsg: UnicodeString;
  TempDir: UnicodeString;
  TempFile: UnicodeString;
  F: File;
  AnsiVerb: AnsiString;
  IsOpen: Boolean;
  IsProps: Boolean;
begin
  Content := '';
  ErrMsg := '';
  Result := FS_EXEC_OK;

  if Verb = nil then
    Exit;

  { TC uebergibt Verb oft als PWideChar trotz PAnsiChar-Signatur.
    Erkennung: PAnsiChar-Lesung ergibt 1 Zeichen → ist Wide }
  AnsiVerb := AnsiString(Verb);
  if Length(AnsiVerb) <= 2 then
    VerbStr := UnicodeString(PWideChar(Pointer(Verb)))
  else
    VerbStr := UnicodeString(AnsiVerb);

  PathStr := UnicodeString(RemoteName);

  LogMsg('FsExecuteFile: Verb="' + VerbStr +
    '" Path="' + PathStr + '"');

  PI := VfsParsePath(PathStr);

  IsOpen  := (CompareText(String(VerbStr), 'open') = 0) or
             (VerbStr = 'o');
  IsProps := (CompareText(String(VerbStr), 'properties') = 0) or
             (VerbStr = 'p');

  { -----------------------------------------------------------
    PROPERTIES (Alt+Enter) — immer Config-Dialog zeigen
    ----------------------------------------------------------- }
  if IsProps then
  begin
    LogMsg('Properties -> config dialog');
    ShowConfigDialog(MainWin);
    Result := FS_EXEC_OK;
    Exit;
  end;

  { -----------------------------------------------------------
    OPEN (Doppelklick / Enter)
    ----------------------------------------------------------- }
  if IsOpen then
  begin
    { [Einstellungen]-Eintrag: Config-Dialog oeffnen }
    if PI.Level = plSettings then
    begin
      LogMsg('Settings opened');
      ShowConfigDialog(MainWin);
      Result := FS_EXEC_OK;
      Exit;
    end;

    { Feed-Ordner: TC soll hinein navigieren }
    if PI.Level = plFeed then
    begin
      LogMsg('Navigate to feed: ' + PI.FeedTitle);
      Result := FS_EXEC_SYMLINK;
      Exit;
    end;

    { Root: TC soll im Root bleiben (Doppelklick auf "..")  }
    if PI.Level = plRoot then
    begin
      Result := FS_EXEC_SYMLINK;
      Exit;
    end;

    { Datei: HTML rendern und im Browser oeffnen }
    if PI.Level = plFile then
    begin
      if VfsGetFileContent(PathStr, Content, ErrMsg) then
      begin
        TempDir := UnicodeString(GetTempDir);
        TempDir := IncludeTrailingPathDelimiter(TempDir) +
          'wfx_rss';
        ForceDirectories(UTF8Encode(TempDir));
        TempFile := IncludeTrailingPathDelimiter(TempDir) +
          PI.FileName;

        try
          AssignFile(F, UTF8Encode(TempFile));
          Rewrite(F, 1);
          if Length(Content) > 0 then
            BlockWrite(F, Content[1], Length(Content));
          CloseFile(F);

          ShellExecuteW(MainWin, 'open',
            PWideChar(TempFile), nil, nil, SW_SHOW);
          Result := FS_EXEC_OK;
        except
          on E: Exception do
          begin
            LogError('Temp file: ' + UnicodeString(E.Message));
            Result := FS_EXEC_ERROR;
          end;
        end;
        Exit;
      end
      else
      begin
        LogError('Content: ' + ErrMsg);
        Result := FS_EXEC_ERROR;
        Exit;
      end;
    end;
  end;

  { Unbekanntes Verb: OK zurueckgeben }
  Result := FS_EXEC_OK;
end;

{ ============================================================
  FsGetFileW — Datei kopieren (F5 in TC)
  ============================================================ }

function FsGetFileW(RemoteName, LocalName: PWideChar;
  CopyFlags: Integer;
  var RemoteInfo: TRemoteInfo): Integer; stdcall;
var
  PathStr: UnicodeString;
  LocalPath: UnicodeString;
  Content: AnsiString;
  ErrMsg: UnicodeString;
  F: File;
begin
  Content := '';
  ErrMsg := '';
  PathStr := UnicodeString(RemoteName);
  LocalPath := UnicodeString(LocalName);

  LogDetail('FsGetFile: ' + PathStr + ' -> ' + LocalPath);

  if FileExists(UTF8Encode(LocalPath)) then
  begin
    if (CopyFlags and FS_COPYFLAGS_OVERWRITE) = 0 then
    begin
      Result := FS_FILE_EXISTS;
      Exit;
    end;
  end;

  if not VfsGetFileContent(PathStr, Content, ErrMsg) then
  begin
    LogError('GetFile: ' + ErrMsg);
    Result := FS_FILE_READERROR;
    Exit;
  end;

  if Assigned(GProgressCbW) then
  begin
    if GProgressCbW(GPluginNr, PWideChar(PathStr),
      PWideChar(LocalPath), 0) <> 0 then
    begin
      Result := FS_FILE_USERABORT;
      Exit;
    end;
  end;

  try
    AssignFile(F, UTF8Encode(LocalPath));
    Rewrite(F, 1);
    if Length(Content) > 0 then
      BlockWrite(F, Content[1], Length(Content));
    CloseFile(F);
  except
    on E: Exception do
    begin
      LogError('Write: ' + UnicodeString(E.Message));
      Result := FS_FILE_WRITEERROR;
      Exit;
    end;
  end;

  if Assigned(GProgressCbW) then
    GProgressCbW(GPluginNr, PWideChar(PathStr),
      PWideChar(LocalPath), 100);

  Result := FS_FILE_OK;
end;

{ ============================================================
  Verzeichnis-Operationen
  ============================================================ }

function FsMkDirW(Path: PWideChar): BOOL; stdcall;
var
  PathStr: UnicodeString;
  PI: TPathInfo;
  URL: UnicodeString;
  Title: UnicodeString;
  BufURL: array[0..1023] of WideChar;
  BufTitle: array[0..1023] of WideChar;
begin
  Result := False;
  PathStr := UnicodeString(Path);
  PI := VfsParsePath(PathStr);
  URL := '';
  Title := '';

  if PI.Level = plFeed then
  begin
    FillChar(BufURL, SizeOf(BufURL), 0);
    FillChar(BufTitle, SizeOf(BufTitle), 0);

    if Assigned(GRequestCbW) then
    begin
      if GRequestCbW(GPluginNr, 0,
        'Add RSS Feed', 'Feed URL:',
        @BufURL[0], SizeOf(BufURL) div SizeOf(WideChar)) then
      begin
        URL := UnicodeString(PWideChar(@BufURL[0]));
        if URL <> '' then
        begin
          Title := PI.FeedTitle;
          if Title = '' then
          begin
            if GRequestCbW(GPluginNr, 0,
              'Add RSS Feed', 'Title:',
              @BufTitle[0],
              SizeOf(BufTitle) div SizeOf(WideChar)) then
            begin
              Title := UnicodeString(
                PWideChar(@BufTitle[0]));
            end;
          end;
          if Title = '' then
            Title := URL;
          ConfigAddFeed(URL, Title);
          VfsClearCache;
          Result := True;
        end;
      end;
    end;
  end;
end;

function FsRemoveDirW(RemoteName: PWideChar): BOOL; stdcall;
var
  PathStr: UnicodeString;
  PI: TPathInfo;
begin
  Result := False;
  PathStr := UnicodeString(RemoteName);
  PI := VfsParsePath(PathStr);
  LogMsg('FsRemoveDirW: ' + PathStr);

  if PI.Level = plFeed then
  begin
    ConfigRemoveFeed(PI.FeedTitle);
    VfsClearFeedCache(PI.FeedTitle);
    Result := True;
    LogMsg('Feed removed: ' + PI.FeedTitle);
  end;
end;

function FsDeleteFileW(RemoteName: PWideChar): BOOL; stdcall;
var
  PathStr: UnicodeString;
  PI: TPathInfo;
begin
  Result := False;
  PathStr := UnicodeString(RemoteName);
  PI := VfsParsePath(PathStr);

  case PI.Level of
    plFeed:
    begin
      { Remove feed from config }
      ConfigRemoveFeed(PI.FeedTitle);
      VfsClearFeedCache(PI.FeedTitle);
      Result := True;
      LogMsg('Feed removed: ' + PI.FeedTitle);
    end;
    plFile:
    begin
      { Virtual articles: just confirm deletion so TC can
        proceed with removing the parent feed folder }
      Result := True;
    end;
  end;
end;

{ ============================================================
  Content-Plugin-Felder
  ============================================================ }

function FsContentGetSupportedField(FieldIndex: Integer;
  FieldName: PAnsiChar; Units: PAnsiChar;
  MaxLen: Integer): Integer; stdcall;
begin
  case FieldIndex of
    0:
    begin
      StrPCopy(FieldName, 'Author');
      Units[0] := #0;
      Result := ft_string;
    end;
    1:
    begin
      StrPCopy(FieldName, 'Category');
      Units[0] := #0;
      Result := ft_string;
    end;
    2:
    begin
      StrPCopy(FieldName, 'Link');
      Units[0] := #0;
      Result := ft_string;
    end;
  else
    Result := ft_nomorefields;
  end;
end;

{ ============================================================
  ANSI-Delegationen (TC kann auch ANSI-Varianten aufrufen)
  ============================================================ }

function FsExecuteFile(MainWin: HWND; RemoteName: PAnsiChar;
  Verb: PAnsiChar): Integer; stdcall;
var
  RemoteW: UnicodeString;
begin
  RemoteW := UnicodeString(AnsiString(RemoteName));
  Result := FsExecuteFileW(MainWin, PWideChar(RemoteW), Verb);
end;

function FsGetFile(RemoteName, LocalName: PAnsiChar;
  CopyFlags: Integer;
  var RemoteInfo: TRemoteInfo): Integer; stdcall;
var
  RemoteW, LocalW: UnicodeString;
begin
  RemoteW := UnicodeString(AnsiString(RemoteName));
  LocalW := UnicodeString(AnsiString(LocalName));
  Result := FsGetFileW(PWideChar(RemoteW), PWideChar(LocalW),
    CopyFlags, RemoteInfo);
end;

function FsRemoveDir(RemoteName: PAnsiChar): BOOL; stdcall;
var
  RemoteW: UnicodeString;
begin
  RemoteW := UnicodeString(AnsiString(RemoteName));
  Result := FsRemoveDirW(PWideChar(RemoteW));
end;

function FsDeleteFile(RemoteName: PAnsiChar): BOOL; stdcall;
var
  RemoteW: UnicodeString;
begin
  RemoteW := UnicodeString(AnsiString(RemoteName));
  Result := FsDeleteFileW(PWideChar(RemoteW));
end;

function FsMkDir(Path: PAnsiChar): BOOL; stdcall;
var
  PathW: UnicodeString;
begin
  PathW := UnicodeString(AnsiString(Path));
  Result := FsMkDirW(PWideChar(PathW));
end;

{ ============================================================
  Exports
  ============================================================ }

exports
  { ANSI Stubs (Pflicht) }
  FsInit,
  FsFindFirst,
  FsFindNext,
  FsExecuteFile,
  FsGetFile,
  FsRemoveDir,
  FsDeleteFile,
  FsMkDir,

  { Unicode }
  FsInitW,
  FsFindFirstW,
  FsFindNextW,
  FsExecuteFileW,
  FsGetFileW,
  FsMkDirW,
  FsRemoveDirW,
  FsDeleteFileW,

  { Gemeinsam }
  FsFindClose,
  FsGetDefRootName,
  FsSetDefaultParams,
  FsLinksToLocalFiles,

  { Content }
  FsContentGetSupportedField;

end.
