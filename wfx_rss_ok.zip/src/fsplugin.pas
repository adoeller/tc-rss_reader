{ ============================================================
  fsplugin.pas — Total Commander WFX Plugin SDK
  Types, constants and callback signatures for the
  file-system plugin interface (Unicode + ANSI stubs).
  ============================================================ }
unit fsplugin;

{$MODE ObjFPC}{$H+}

interface

uses
  Windows;

const
  FS_FILE_OK              = 0;
  FS_FILE_EXISTS          = 1;
  FS_FILE_NOTFOUND        = 2;
  FS_FILE_READERROR       = 3;
  FS_FILE_WRITEERROR      = 4;
  FS_FILE_USERABORT       = 5;
  FS_FILE_NOTSUPPORTED    = 6;
  FS_FILE_EXISTSRESUMEPERMITTED = 7;

  FS_EXEC_OK              = 0;
  FS_EXEC_ERROR           = 1;
  FS_EXEC_YOURSELF        = -1;
  FS_EXEC_SYMLINK         = 2;

  FS_COPYFLAGS_OVERWRITE      = 1;
  FS_COPYFLAGS_RESUME         = 2;
  FS_COPYFLAGS_MOVE           = 4;

  msgtype_connect         = 1;
  msgtype_disconnect      = 2;
  msgtype_details         = 3;
  msgtype_transfercomplete = 4;
  msgtype_connectcomplete = 5;
  msgtype_importanterror  = 6;
  msgtype_operationcomplete = 7;

  ft_nomorefields     = 0;
  ft_numeric_32       = 1;
  ft_numeric_64       = 2;
  ft_numeric_floating = 3;
  ft_date             = 4;
  ft_time             = 5;
  ft_boolean          = 6;
  ft_multiplechoice   = 7;
  ft_string           = 8;
  ft_fulltext         = 9;
  ft_datetime         = 10;

  BG_DOWNLOAD           = 1;
  BG_UPLOAD             = 2;
  BG_ASK_USER           = 4;

type
  PRemoteInfo = ^TRemoteInfo;
  TRemoteInfo = record
    SizeLow: DWORD;
    SizeHigh: DWORD;
    LastWriteTime: TFileTime;
    Attr: Integer;
  end;

  PFsDefaultParamStruct = ^TFsDefaultParamStruct;
  TFsDefaultParamStruct = record
    size: DWORD;
    PluginInterfaceVersionLow: DWORD;
    PluginInterfaceVersionHi: DWORD;
    DefaultIniName: array[0..MAX_PATH-1] of AnsiChar;
  end;

  TProgressProc = function(PluginNr: Integer;
    SourceName, TargetName: PAnsiChar;
    PercentDone: Integer): Integer; stdcall;

  TLogProc = procedure(PluginNr: Integer;
    MsgType: Integer;
    LogString: PAnsiChar); stdcall;

  TRequestProc = function(PluginNr: Integer;
    RequestType: Integer;
    CustomTitle, CustomText: PAnsiChar;
    ReturnedText: PAnsiChar;
    MaxLen: Integer): LongBool; stdcall;

  TProgressProcW = function(PluginNr: Integer;
    SourceName, TargetName: PWideChar;
    PercentDone: Integer): Integer; stdcall;

  TLogProcW = procedure(PluginNr: Integer;
    MsgType: Integer;
    LogString: PWideChar); stdcall;

  TRequestProcW = function(PluginNr: Integer;
    RequestType: Integer;
    CustomTitle, CustomText: PWideChar;
    ReturnedText: PWideChar;
    MaxLen: Integer): LongBool; stdcall;

var
  GPluginNr: Integer = 0;
  GProgressCb: TProgressProc = nil;
  GLogCb: TLogProc = nil;
  GRequestCb: TRequestProc = nil;
  GProgressCbW: TProgressProcW = nil;
  GLogCbW: TLogProcW = nil;
  GRequestCbW: TRequestProcW = nil;

implementation

end.
