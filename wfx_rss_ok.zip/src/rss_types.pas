{ ============================================================
  rss_types.pas — Gemeinsame Datentypen
  ============================================================ }
unit rss_types;

{$MODE ObjFPC}{$H+}

interface

uses
  Windows, SysUtils;

type
  TRssFeedItem = record
    Title: UnicodeString;
    Link: UnicodeString;
    Description: UnicodeString;
    PubDate: UnicodeString;
    Author: UnicodeString;
    Category: UnicodeString;
    Guid: UnicodeString;
    Comments: UnicodeString;
    Enclosure: UnicodeString;
    Source: UnicodeString;
    PubDateTime: TDateTime;
    FileName: UnicodeString;
  end;

  TRssFeedItemArray = array of TRssFeedItem;

  TRssFeed = record
    Title: UnicodeString;
    Link: UnicodeString;
    Description: UnicodeString;
    Language: UnicodeString;
    PubDate: UnicodeString;
    LastBuildDate: UnicodeString;
    ManagingEditor: UnicodeString;
    URL: UnicodeString;
    Items: TRssFeedItemArray;
    LastFetch: TDateTime;
    CacheValid: Boolean;
  end;

  TRssFeedArray = array of TRssFeed;

  TProxyConfig = record
    ProxyType: Integer;
    Server: UnicodeString;
    Port: Integer;
    User: UnicodeString;
    Password: UnicodeString;
  end;

  TPluginConfig = record
    IniPath: UnicodeString;
    TemplateName: UnicodeString;
    TemplateNameDark: UnicodeString;
    TemplateContent: UnicodeString;
    TemplateContentDark: UnicodeString;
    Proxy: TProxyConfig;
    RefreshX: Integer;
    RefreshY: Integer;
    OpenLinksNewWindow: Boolean;
    FeedURLs: array of UnicodeString;
    FeedTitles: array of UnicodeString;
    FeedLastFetch: array of TDateTime;
    FeedPrevLastFetch: array of TDateTime;  { loaded at startup, never updated }
    FeedItemCount: array of Integer;
  end;

  TSearchContext = record
    Path: UnicodeString;
    Index: Integer;
    Items: array of TWin32FindDataW;
    Valid: Boolean;
  end;
  PSearchContext = ^TSearchContext;

function SanitizeFileName(const S: UnicodeString): UnicodeString;
function TryParseRssDate(const S: UnicodeString; out DT: TDateTime): Boolean;
function DateTimeToFileTime2(DT: TDateTime): TFileTime;

implementation

function SanitizeFileName(const S: UnicodeString): UnicodeString;
var
  I: Integer;
  Ch: WideChar;
begin
  Result := '';
  for I := 1 to Length(S) do
  begin
    Ch := S[I];
    case Ch of
      '\', '/', ':', '*', '?', '"', '<', '>', '|':
        Result := Result + '_';
    else
      Result := Result + Ch;
    end;
  end;
  if Length(Result) > 120 then
    Result := Copy(Result, 1, 120);
  Result := TrimRight(Result);
  if Result = '' then
    Result := 'untitled';
end;

function TryParseRssDate(const S: UnicodeString; out DT: TDateTime): Boolean;
var
  Trimmed: UnicodeString;
  Parts: array[0..9] of UnicodeString;
  PartCount: Integer;
  I, P: Integer;
  Day, Month, Year, Hour, Min, Sec: Word;
  MonStr: UnicodeString;
  Tmp: UnicodeString;

  procedure SplitParts(const Src: UnicodeString);
  var
    C: Integer;
    Start: Integer;
  begin
    PartCount := 0;
    Start := 1;
    for C := 1 to Length(Src) do
    begin
      if (Src[C] = ' ') or (Src[C] = 'T') then
      begin
        if C > Start then
        begin
          if PartCount <= High(Parts) then
          begin
            Parts[PartCount] := Copy(Src, Start, C - Start);
            Inc(PartCount);
          end;
        end;
        Start := C + 1;
      end;
    end;
    if Start <= Length(Src) then
    begin
      if PartCount <= High(Parts) then
      begin
        Parts[PartCount] := Copy(Src, Start, MaxInt);
        Inc(PartCount);
      end;
    end;
  end;

  function MonthFromStr(const M: UnicodeString): Word;
  var
    ML: string;
  begin
    ML := LowerCase(String(M));
    if ML = 'jan' then Result := 1
    else if ML = 'feb' then Result := 2
    else if ML = 'mar' then Result := 3
    else if ML = 'apr' then Result := 4
    else if ML = 'may' then Result := 5
    else if ML = 'jun' then Result := 6
    else if ML = 'jul' then Result := 7
    else if ML = 'aug' then Result := 8
    else if ML = 'sep' then Result := 9
    else if ML = 'oct' then Result := 10
    else if ML = 'nov' then Result := 11
    else if ML = 'dec' then Result := 12
    else Result := 0;
  end;

  function ParseTime(const T: UnicodeString;
    out H, M2, S2: Word): Boolean;
  var
    TP: array[0..2] of UnicodeString;
    TC: Integer;
    Start2: Integer;
    C2: Integer;
  begin
    Result := False;
    H := 0; M2 := 0; S2 := 0;
    TC := 0;
    Start2 := 1;
    for C2 := 1 to Length(T) do
    begin
      if T[C2] = ':' then
      begin
        if TC <= 2 then
          TP[TC] := Copy(T, Start2, C2 - Start2);
        Inc(TC);
        Start2 := C2 + 1;
      end;
    end;
    if TC <= 2 then
      TP[TC] := Copy(T, Start2, MaxInt);
    Inc(TC);
    if TC < 2 then Exit;
    H := StrToIntDef(String(TP[0]), 99);
    M2 := StrToIntDef(String(TP[1]), 99);
    if TC >= 3 then
      S2 := StrToIntDef(String(TP[2]), 0);
    Result := (H < 24) and (M2 < 60);
  end;

begin
  Result := False;
  DT := 0;
  Trimmed := Trim(S);
  if Trimmed = '' then
    Exit;

  { Strip day name: "Thu, 07 May 2026..." -> "07 May 2026..." }
  P := Pos(',', Trimmed);
  if (P > 0) and (P <= 4) then
    Trimmed := Trim(Copy(Trimmed, P + 1, MaxInt));

  SplitParts(Trimmed);

  { RFC 822: "07 May 2026 14:46:01 +0000" }
  { Parts:   0=07, 1=May, 2=2026, 3=14:46:01, 4=+0000 }
  if (PartCount >= 4) then
  begin
    Day := StrToIntDef(String(Parts[0]), 0);
    MonStr := Parts[1];
    Month := MonthFromStr(MonStr);
    Year := StrToIntDef(String(Parts[2]), 0);

    if (Day >= 1) and (Day <= 31) and (Month >= 1) and
      (Month <= 12) and (Year >= 1900) then
    begin
      if ParseTime(Parts[3], Hour, Min, Sec) then
      begin
        try
          DT := EncodeDate(Year, Month, Day) +
            EncodeTime(Hour, Min, Sec, 0);
          Result := True;
          Exit;
        except
        end;
      end;
    end;
  end;

  { ISO 8601: "2026-05-07T14:46:01Z" or "2026-05-07 14:46:01" }
  if (Length(Trimmed) >= 10) and (Trimmed[5] = '-') and
    (Trimmed[8] = '-') then
  begin
    Year := StrToIntDef(String(Copy(Trimmed, 1, 4)), 0);
    Month := StrToIntDef(String(Copy(Trimmed, 6, 2)), 0);
    Day := StrToIntDef(String(Copy(Trimmed, 9, 2)), 0);
    Hour := 0; Min := 0; Sec := 0;
    if Length(Trimmed) >= 16 then
    begin
      Tmp := Copy(Trimmed, 12, MaxInt);
      { Remove timezone suffix }
      P := Pos('Z', Tmp);
      if P > 0 then Tmp := Copy(Tmp, 1, P - 1);
      P := Pos('+', Tmp);
      if P > 1 then Tmp := Copy(Tmp, 1, P - 1);
      ParseTime(Tmp, Hour, Min, Sec);
    end;
    if (Year >= 1900) and (Month >= 1) and (Month <= 12) and
      (Day >= 1) and (Day <= 31) then
    begin
      try
        DT := EncodeDate(Year, Month, Day) +
          EncodeTime(Hour, Min, Sec, 0);
        Result := True;
      except
      end;
    end;
  end;
end;

function DateTimeToFileTime2(DT: TDateTime): TFileTime;
var
  ST: TSystemTime;
  LFT: TFileTime;
begin
  Result.dwLowDateTime := 0;
  Result.dwHighDateTime := 0;
  if DT <= 0 then
    Exit;
  try
    DateTimeToSystemTime(DT, ST);
    if SystemTimeToFileTime(@ST, @LFT) then
      LocalFileTimeToFileTime(@LFT, @Result);
  except
  end;
end;

end.
