{ ============================================================
  rss_http.pas — HTTP via WinInet with proxy support
  ============================================================ }
unit rss_http;

{$MODE ObjFPC}{$H+}

interface

uses
  Windows, SysUtils;

function HttpGet(const URL: UnicodeString; out Body: AnsiString;
  out ContentType: AnsiString; out ErrMsg: UnicodeString): Boolean;

implementation

uses
  rss_log, rss_config;

const
  INTERNET_OPEN_TYPE_PRECONFIG  = 0;
  INTERNET_OPEN_TYPE_DIRECT     = 1;
  INTERNET_OPEN_TYPE_PROXY      = 3;
  INTERNET_FLAG_RELOAD          = $80000000;
  INTERNET_FLAG_NO_CACHE_WRITE  = $04000000;
  INTERNET_FLAG_PRAGMA_NOCACHE  = $00000100;
  INTERNET_FLAG_NO_UI           = $00000200;

  INTERNET_OPTION_PROXY_USERNAME = 43;
  INTERNET_OPTION_PROXY_PASSWORD = 44;

  HTTP_QUERY_CONTENT_TYPE = 1;

type
  HINTERNET = Pointer;

function InternetOpenW(lpszAgent: PWideChar; dwAccessType: DWORD;
  lpszProxy, lpszProxyBypass: PWideChar;
  dwFlags: DWORD): HINTERNET; stdcall;
  external 'wininet.dll' name 'InternetOpenW';

function InternetOpenUrlW(hInet: HINTERNET; lpszUrl: PWideChar;
  lpszHeaders: PWideChar; dwHeadersLength: DWORD;
  dwFlags: DWORD; dwContext: DWORD_PTR): HINTERNET; stdcall;
  external 'wininet.dll' name 'InternetOpenUrlW';

function InternetReadFile(hFile: HINTERNET; lpBuffer: Pointer;
  dwNumberOfBytesToRead: DWORD;
  var lpdwNumberOfBytesRead: DWORD): BOOL; stdcall;
  external 'wininet.dll' name 'InternetReadFile';

function InternetCloseHandle(hInet: HINTERNET): BOOL; stdcall;
  external 'wininet.dll' name 'InternetCloseHandle';

function InternetSetOptionW(hInet: HINTERNET;
  dwOption: DWORD; lpBuffer: Pointer;
  dwBufferLength: DWORD): BOOL; stdcall;
  external 'wininet.dll' name 'InternetSetOptionW';

function HttpQueryInfoA(hRequest: HINTERNET; dwInfoLevel: DWORD;
  lpBuffer: Pointer; var dwBufferLen: DWORD;
  lpIndex: Pointer): BOOL; stdcall;
  external 'wininet.dll' name 'HttpQueryInfoA';

function HttpGet(const URL: UnicodeString; out Body: AnsiString;
  out ContentType: AnsiString; out ErrMsg: UnicodeString): Boolean;
var
  hSession: HINTERNET;
  hUrl: HINTERNET;
  Buffer: array[0..8191] of Byte;
  BytesRead: DWORD;
  Flags: DWORD;
  OldLen: Integer;
  AccessType: DWORD;
  ProxyStr: UnicodeString;
  ProxyUser: UnicodeString;
  ProxyPass: UnicodeString;
  CTBuf: array[0..511] of AnsiChar;
  CTLen: DWORD;
begin
  Result := False;
  Body := '';
  ContentType := '';
  ErrMsg := '';
  hSession := nil;
  hUrl := nil;

  try
    { Proxy-Konfiguration auswerten }
    AccessType := INTERNET_OPEN_TYPE_PRECONFIG;
    ProxyStr := '';

    if GConfig.Proxy.ProxyType = 1 then
    begin
      { HTTP Proxy }
      if GConfig.Proxy.Server <> '' then
      begin
        AccessType := INTERNET_OPEN_TYPE_PROXY;
        ProxyStr := 'http://' + GConfig.Proxy.Server;
        if GConfig.Proxy.Port > 0 then
          ProxyStr := ProxyStr + ':' +
            IntToStr(GConfig.Proxy.Port);
      end;
    end
    else if GConfig.Proxy.ProxyType = 2 then
    begin
      { SOCKS5 Proxy }
      if GConfig.Proxy.Server <> '' then
      begin
        AccessType := INTERNET_OPEN_TYPE_PROXY;
        ProxyStr := 'socks=' + GConfig.Proxy.Server;
        if GConfig.Proxy.Port > 0 then
          ProxyStr := ProxyStr + ':' +
            IntToStr(GConfig.Proxy.Port);
      end;
    end
    else if GConfig.Proxy.ProxyType = 3 then
    begin
      { Direct / No proxy }
      AccessType := INTERNET_OPEN_TYPE_DIRECT;
    end;
    { ProxyType=0: PRECONFIG (system default) }

    if ProxyStr <> '' then
      hSession := InternetOpenW(PWideChar('WFX_RSS/1.0'),
        AccessType, PWideChar(ProxyStr), nil, 0)
    else
      hSession := InternetOpenW(PWideChar('WFX_RSS/1.0'),
        AccessType, nil, nil, 0);

    if hSession = nil then
    begin
      ErrMsg := 'InternetOpen failed: ' +
        SysErrorMessage(GetLastError);
      Exit;
    end;

    { Proxy-Authentifizierung }
    ProxyUser := GConfig.Proxy.User;
    ProxyPass := GConfig.Proxy.Password;
    if ProxyUser <> '' then
    begin
      InternetSetOptionW(hSession,
        INTERNET_OPTION_PROXY_USERNAME,
        PWideChar(ProxyUser),
        Length(ProxyUser) * SizeOf(WideChar));
      if ProxyPass <> '' then
        InternetSetOptionW(hSession,
          INTERNET_OPTION_PROXY_PASSWORD,
          PWideChar(ProxyPass),
          Length(ProxyPass) * SizeOf(WideChar));
    end;

    Flags := INTERNET_FLAG_RELOAD or
      INTERNET_FLAG_NO_CACHE_WRITE or
      INTERNET_FLAG_PRAGMA_NOCACHE or
      INTERNET_FLAG_NO_UI;
    hUrl := InternetOpenUrlW(hSession, PWideChar(URL),
      nil, 0, Flags, 0);
    if hUrl = nil then
    begin
      ErrMsg := 'InternetOpenUrl failed for ' + URL +
        ': ' + SysErrorMessage(GetLastError);
      Exit;
    end;

    { Read Content-Type header }
    FillChar(CTBuf, SizeOf(CTBuf), 0);
    CTLen := SizeOf(CTBuf) - 1;
    if HttpQueryInfoA(hUrl, HTTP_QUERY_CONTENT_TYPE,
      @CTBuf[0], CTLen, nil) then
      ContentType := AnsiString(PAnsiChar(@CTBuf[0]));

    repeat
      BytesRead := 0;
      if not InternetReadFile(hUrl, @Buffer[0],
        SizeOf(Buffer), BytesRead) then
      begin
        ErrMsg := 'InternetReadFile failed: ' +
          SysErrorMessage(GetLastError);
        Exit;
      end;
      if BytesRead > 0 then
      begin
        OldLen := Length(Body);
        SetLength(Body, OldLen + Integer(BytesRead));
        Move(Buffer[0], Body[OldLen + 1], BytesRead);
      end;
    until BytesRead = 0;

    Result := True;
    LogDetail('HTTP GET OK: ' + URL + ' (' +
      IntToStr(Length(Body)) + ' bytes)');
  except
    on E: Exception do
    begin
      ErrMsg := 'HTTP exception: ' + UnicodeString(E.Message);
      LogError(ErrMsg);
    end;
  end;

  if hUrl <> nil then
    InternetCloseHandle(hUrl);
  if hSession <> nil then
    InternetCloseHandle(hSession);
end;

end.
