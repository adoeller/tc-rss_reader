{ ============================================================
  rss_crypto.pas — Password encryption via Windows DPAPI
  with XOR+Base64 fallback.
  ============================================================ }
unit rss_crypto;

{$MODE ObjFPC}{$H+}

interface

uses
  Windows, SysUtils;

function EncryptString(const Plain: UnicodeString): UnicodeString;
function DecryptString(const Cipher: UnicodeString): UnicodeString;

implementation

const
  CRYPTPROTECT_UI_FORBIDDEN = 1;
  XOR_KEY = $A7;

type
  TDataBlob = record
    cbData: DWORD;
    pbData: PByte;
  end;
  PDataBlob = ^TDataBlob;

function CryptProtectData(pDataIn: PDataBlob;
  szDataDescr: PWideChar;
  pOptionalEntropy: PDataBlob;
  pvReserved: Pointer;
  pPromptStruct: Pointer;
  dwFlags: DWORD;
  pDataOut: PDataBlob): BOOL; stdcall;
  external 'crypt32.dll' name 'CryptProtectData';

function CryptUnprotectData(pDataIn: PDataBlob;
  ppszDataDescr: PWideChar;
  pOptionalEntropy: PDataBlob;
  pvReserved: Pointer;
  pPromptStruct: Pointer;
  dwFlags: DWORD;
  pDataOut: PDataBlob): BOOL; stdcall;
  external 'crypt32.dll' name 'CryptUnprotectData';

function LocalFree(hMem: HLOCAL): HLOCAL; stdcall;
  external 'kernel32.dll' name 'LocalFree';

{ Base64 encode/decode for AnsiString bytes }
function Base64Encode(const Bytes: AnsiString): UnicodeString;
const
  Tbl: AnsiString =
    'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
var
  I, Len: Integer;
  B: array[0..2] of Byte;
  Out4: array[0..3] of Byte;
  R: AnsiString;
begin
  Result := '';
  R := '';
  Len := Length(Bytes);
  I := 1;
  while I <= Len do
  begin
    B[0] := 0; B[1] := 0; B[2] := 0;
    B[0] := Byte(Bytes[I]);
    if I + 1 <= Len then B[1] := Byte(Bytes[I + 1]);
    if I + 2 <= Len then B[2] := Byte(Bytes[I + 2]);

    Out4[0] := B[0] shr 2;
    Out4[1] := ((B[0] and 3) shl 4) or (B[1] shr 4);
    Out4[2] := ((B[1] and 15) shl 2) or (B[2] shr 6);
    Out4[3] := B[2] and 63;

    R := R + Tbl[Out4[0] + 1] + Tbl[Out4[1] + 1];
    if I + 1 <= Len then R := R + Tbl[Out4[2] + 1] else R := R + '=';
    if I + 2 <= Len then R := R + Tbl[Out4[3] + 1] else R := R + '=';

    Inc(I, 3);
  end;
  Result := UnicodeString(R);
end;

function Base64Decode(const S: UnicodeString): AnsiString;
const
  Tbl: AnsiString =
    'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
var
  I, Len: Integer;
  B: array[0..3] of Integer;
  Idx: Integer;
  Ch: AnsiChar;
  K: Integer;
begin
  Result := '';
  Len := Length(S);
  I := 1;
  while I <= Len do
  begin
    for K := 0 to 3 do B[K] := -1;
    for K := 0 to 3 do
    begin
      if I + K > Len then Break;
      Ch := AnsiChar(S[I + K]);
      if Ch = '=' then Break;
      Idx := Pos(Ch, Tbl);
      if Idx = 0 then Continue;
      B[K] := Idx - 1;
    end;

    if B[0] >= 0 then
    begin
      if B[1] >= 0 then
        Result := Result + AnsiChar(Byte((B[0] shl 2) or (B[1] shr 4)));
      if B[2] >= 0 then
        Result := Result + AnsiChar(Byte(((B[1] and 15) shl 4) or (B[2] shr 2)));
      if B[3] >= 0 then
        Result := Result + AnsiChar(Byte(((B[2] and 3) shl 6) or B[3]));
    end;

    Inc(I, 4);
  end;
end;

{ XOR fallback }
function XorEncrypt(const Plain: UnicodeString): AnsiString;
var
  I: Integer;
  S: AnsiString;
begin
  S := UTF8Encode(Plain);
  Result := '';
  for I := 1 to Length(S) do
    Result := Result + AnsiChar(Byte(S[I]) xor XOR_KEY);
end;

function XorDecrypt(const Cipher: AnsiString): UnicodeString;
var
  I: Integer;
  S: AnsiString;
begin
  S := '';
  for I := 1 to Length(Cipher) do
    S := S + AnsiChar(Byte(Cipher[I]) xor XOR_KEY);
  Result := UTF8Decode(S);
end;

function EncryptString(const Plain: UnicodeString): UnicodeString;
var
  In_, Out_: TDataBlob;
  PlainBytes: AnsiString;
  CipherBytes: AnsiString;
  I: Integer;
begin
  Result := '';
  if Plain = '' then Exit;

  PlainBytes := UTF8Encode(Plain);

  In_.cbData := Length(PlainBytes);
  In_.pbData := nil;
  if Length(PlainBytes) > 0 then
    In_.pbData := @PlainBytes[1];

  Out_.cbData := 0;
  Out_.pbData := nil;

  if CryptProtectData(@In_, nil, nil, nil, nil,
    CRYPTPROTECT_UI_FORBIDDEN, @Out_) then
  begin
    CipherBytes := '';
    SetLength(CipherBytes, Out_.cbData);
    for I := 0 to Out_.cbData - 1 do
      CipherBytes[I + 1] := AnsiChar(Out_.pbData[I]);
    LocalFree(HLOCAL(Out_.pbData));
    Result := 'D:' + Base64Encode(CipherBytes);
  end
  else
  begin
    Result := 'X:' + Base64Encode(XorEncrypt(Plain));
  end;
end;

function DecryptString(const Cipher: UnicodeString): UnicodeString;
var
  In_, Out_: TDataBlob;
  Prefix: UnicodeString;
  Payload: UnicodeString;
  Bytes: AnsiString;
  Plain: AnsiString;
  I: Integer;
begin
  Result := '';
  if Cipher = '' then Exit;

  if Length(Cipher) < 2 then Exit;
  Prefix := Copy(Cipher, 1, 2);
  Payload := Copy(Cipher, 3, MaxInt);

  if Prefix = 'X:' then
  begin
    Bytes := Base64Decode(Payload);
    Result := XorDecrypt(Bytes);
    Exit;
  end;

  if Prefix <> 'D:' then
  begin
    Result := Cipher;
    Exit;
  end;

  Bytes := Base64Decode(Payload);
  if Bytes = '' then Exit;

  In_.cbData := Length(Bytes);
  In_.pbData := @Bytes[1];

  Out_.cbData := 0;
  Out_.pbData := nil;

  if CryptUnprotectData(@In_, nil, nil, nil, nil,
    CRYPTPROTECT_UI_FORBIDDEN, @Out_) then
  begin
    Plain := '';
    SetLength(Plain, Out_.cbData);
    for I := 0 to Out_.cbData - 1 do
      Plain[I + 1] := AnsiChar(Out_.pbData[I]);
    LocalFree(HLOCAL(Out_.pbData));
    Result := UTF8Decode(Plain);
  end;
end;

end.
