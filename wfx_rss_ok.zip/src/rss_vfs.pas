{ ============================================================
  rss_vfs.pas — Virtuelles Dateisystem und Feed-Cache

  Root zeigt:
    [Settings].cfg  (DATEI — Doppelklick oeffnet Dialog)
    Feed-Ordner...
  ============================================================ }
unit rss_vfs;

{$MODE ObjFPC}{$H+}

interface

uses
  Windows, SysUtils, rss_types, fsplugin;

const
  SETTINGS_FILE_NAME: UnicodeString = '[Settings].cfg';

procedure VfsInit;

type
  TPathLevel = (plRoot, plFeed, plFile, plSettings, plUnknown);

  TPathInfo = record
    Level: TPathLevel;
    FeedTitle: UnicodeString;
    FileName: UnicodeString;
  end;

function  VfsParsePath(const Path: UnicodeString): TPathInfo;
function  VfsFindFirst(const Path: UnicodeString;
  out FindData: TWin32FindDataW): THandle;
function  VfsFindNext(SearchHandle: THandle;
  out FindData: TWin32FindDataW): Boolean;
procedure VfsFindClose(SearchHandle: THandle);
function  VfsGetFileContent(const Path: UnicodeString;
  out Content: AnsiString; out ErrMsg: UnicodeString): Boolean;
function  VfsGetFeed(const Title: UnicodeString;
  out Feed: TRssFeed; out ErrMsg: UnicodeString): Boolean;
procedure VfsClearCache;
procedure VfsClearFeedCache(const Title: UnicodeString);

implementation

uses
  rss_log, rss_config, rss_http, rss_parser, rss_template;

const
  MAX_CTX = 64;
  CACHE_TTL_MIN = 5;

type
  TSearchCtx = record
    Used: Boolean;
    PI: TPathInfo;
    Feed: TRssFeed;
    Idx: Integer;
    Total: Integer;
    PrevLastFetch: TDateTime;
  end;

function IfThenInt(Cond: Boolean; A, B: Int64): Int64;
begin
  if Cond then Result := A else Result := B;
end;

var
  GCtx: array[0..MAX_CTX-1] of TSearchCtx;
  GCache: array of TRssFeed;
  GCacheLock: TRTLCriticalSection;
  GCtxLock: TRTLCriticalSection;
  GReady: Boolean;

procedure VfsInit;
var
  I: Integer;
begin
  if GReady then Exit;
  InitializeCriticalSection(GCacheLock);
  InitializeCriticalSection(GCtxLock);
  for I := 0 to MAX_CTX-1 do
    GCtx[I].Used := False;
  GCache := nil;
  GReady := True;
end;

function VfsParsePath(const Path: UnicodeString): TPathInfo;
var
  S: UnicodeString;
  P: Integer;
begin
  Result := Default(TPathInfo);
  S := Path;
  while (Length(S) > 0) and (S[1] = '\') do Delete(S, 1, 1);
  while (Length(S) > 0) and (S[Length(S)] = '\') do Delete(S, Length(S), 1);

  if S = '' then begin Result.Level := plRoot; Exit; end;

  if CompareText(String(S), String(SETTINGS_FILE_NAME)) = 0 then
  begin
    Result.Level := plSettings;
    Exit;
  end;

  P := Pos('\', S);
  if P = 0 then
  begin
    Result.Level := plFeed;
    Result.FeedTitle := S;
    Exit;
  end;

  Result.Level := plFile;
  Result.FeedTitle := Copy(S, 1, P-1);
  Result.FileName := Copy(S, P+1, MaxInt);
end;

function AllocCtx: Integer;
var I: Integer;
begin
  Result := -1;
  EnterCriticalSection(GCtxLock);
  try
    for I := 0 to MAX_CTX-1 do
      if not GCtx[I].Used then
      begin
        GCtx[I].Used := True;
        GCtx[I].Idx := 0;
        GCtx[I].Total := 0;
        Result := I;
        Exit;
      end;
  finally
    LeaveCriticalSection(GCtxLock);
  end;
end;

procedure FreeCtx(X: Integer);
begin
  if (X < 0) or (X >= MAX_CTX) then Exit;
  EnterCriticalSection(GCtxLock);
  try
    GCtx[X].Used := False;
    GCtx[X].Feed := Default(TRssFeed);
  finally
    LeaveCriticalSection(GCtxLock);
  end;
end;

function FetchFeed(const Title: UnicodeString;
  out Feed: TRssFeed; out ErrMsg: UnicodeString): Boolean;
var
  URL: UnicodeString;
  Body: AnsiString;
  ContentType: AnsiString;
  I: Integer;
  Found: Boolean;
begin
  Result := False;
  Feed := Default(TRssFeed);
  Body := '';
  ContentType := '';
  ErrMsg := '';
  URL := ConfigGetFeedURL(Title);
  if URL = '' then begin ErrMsg := 'Feed not configured: ' + Title; Exit; end;

  EnterCriticalSection(GCacheLock);
  try
    for I := 0 to Length(GCache)-1 do
      if GCache[I].Title = Title then
        if GCache[I].CacheValid and
           ((Now - GCache[I].LastFetch)*24*60 < CACHE_TTL_MIN) then
        begin
          Feed := GCache[I];
          Result := True;
          Exit;
        end
        else Break;
  finally
    LeaveCriticalSection(GCacheLock);
  end;

  LogMsg('Loading feed: ' + URL);
  if not HttpGet(URL, Body, ContentType, ErrMsg) then Exit;
  if not ParseRssFeed(Body, URL, ContentType, Feed, ErrMsg) then Exit;
  Feed.Title := Title;

  EnterCriticalSection(GCacheLock);
  try
    Found := False;
    for I := 0 to Length(GCache)-1 do
      if GCache[I].Title = Title then
      begin GCache[I] := Feed; Found := True; Break; end;
    if not Found then
    begin
      SetLength(GCache, Length(GCache)+1);
      GCache[High(GCache)] := Feed;
    end;
  finally
    LeaveCriticalSection(GCacheLock);
  end;

  { Save fetch timestamp to INI }
  ConfigUpdateLastFetch(Title, Now, Length(Feed.Items));

  Result := True;
end;

procedure FillDir(out FD: TWin32FindDataW;
  const Name: UnicodeString; ModTime: TDateTime; Size: Int64);
var
  Len: Integer;
  FT: TFileTime;
begin
  FillChar(FD, SizeOf(FD), 0);
  FD.dwFileAttributes := FILE_ATTRIBUTE_DIRECTORY;
  FD.nFileSizeLow := DWORD(Size and $FFFFFFFF);
  FD.nFileSizeHigh := DWORD(Size shr 32);
  if ModTime > 0 then
  begin
    FT := DateTimeToFileTime2(ModTime);
    FD.ftLastWriteTime := FT;
    FD.ftCreationTime := FT;
  end;
  Len := Length(Name);
  if Len >= MAX_PATH then Len := MAX_PATH-1;
  if Len > 0 then Move(Name[1], FD.cFileName[0], Len*SizeOf(WideChar));
end;

procedure FillFile(out FD: TWin32FindDataW; const Name: UnicodeString;
  Size: Int64; ModTime: TDateTime);
var Len: Integer; FT: TFileTime;
begin
  FillChar(FD, SizeOf(FD), 0);
  FD.dwFileAttributes := FILE_ATTRIBUTE_NORMAL;
  FD.nFileSizeLow := DWORD(Size and $FFFFFFFF);
  FD.nFileSizeHigh := DWORD(Size shr 32);
  if ModTime > 0 then
  begin
    FT := DateTimeToFileTime2(ModTime);
    FD.ftLastWriteTime := FT;
    FD.ftCreationTime := FT;
  end;
  Len := Length(Name);
  if Len >= MAX_PATH then Len := MAX_PATH-1;
  if Len > 0 then Move(Name[1], FD.cFileName[0], Len*SizeOf(WideChar));
end;

{ Root: Index 0 = [Settings].cfg (DATEI!), 1..N = Feeds (Ordner) }
function VfsFindFirst(const Path: UnicodeString;
  out FindData: TWin32FindDataW): THandle;
var
  PI: TPathInfo;
  X: Integer;
  Feed: TRssFeed;
  ErrMsg: UnicodeString;
begin
  Result := INVALID_HANDLE_VALUE;
  FillChar(FindData, SizeOf(FindData), 0);
  ErrMsg := '';
  if not GReady then VfsInit;

  PI := VfsParsePath(Path);
  X := AllocCtx;
  if X < 0 then begin LogError('No free search context'); Exit; end;
  GCtx[X].PI := PI;

  case PI.Level of
    plRoot:
    begin
      GCtx[X].Total := Length(GConfig.FeedTitles) + 1;
      { Erstes Element: [Settings].cfg als DATEI }
      FillFile(FindData, SETTINGS_FILE_NAME, 0, 0);
      GCtx[X].Idx := 1;
      Result := THandle(X + 1);
    end;

    plFeed:
    begin
      Feed := Default(TRssFeed);
      { Read previous fetch time from session-start snapshot }
      GCtx[X].PrevLastFetch := ConfigGetPrevLastFetch(PI.FeedTitle);
      if not FetchFeed(PI.FeedTitle, Feed, ErrMsg) then
      begin LogError('Feed: ' + ErrMsg); FreeCtx(X); Exit; end;
      GCtx[X].Feed := Feed;
      if Length(Feed.Items) = 0 then begin FreeCtx(X); Exit; end;

      FillFile(FindData, Feed.Items[0].FileName,
        IfThenInt(Feed.Items[0].PubDateTime > GCtx[X].PrevLastFetch, 1, 0),
        Feed.Items[0].PubDateTime);
      LogDetail('Size[0] ' + String(Feed.Items[0].FileName) +
        ' pub=' + FloatToStr(Feed.Items[0].PubDateTime) +
        ' prev=' + FloatToStr(GCtx[X].PrevLastFetch) +
        ' newer=' + BoolToStr(
          Feed.Items[0].PubDateTime > GCtx[X].PrevLastFetch, True));
      GCtx[X].Total := Length(Feed.Items);
      GCtx[X].Idx := 1;
      Result := THandle(X + 1);
    end;
  else
    FreeCtx(X);
  end;
end;

function VfsFindNext(SearchHandle: THandle;
  out FindData: TWin32FindDataW): Boolean;
var
  X, FI: Integer;
begin
  Result := False;
  FillChar(FindData, SizeOf(FindData), 0);
  X := Integer(SearchHandle) - 1;
  if (X < 0) or (X >= MAX_CTX) or (not GCtx[X].Used) then Exit;

  case GCtx[X].PI.Level of
    plRoot:
    begin
      FI := GCtx[X].Idx - 1;
      if FI >= Length(GConfig.FeedTitles) then Exit;
      FillDir(FindData, GConfig.FeedTitles[FI],
        ConfigGetLastFetch(GConfig.FeedTitles[FI]),
        ConfigGetItemCount(GConfig.FeedTitles[FI]));
      Inc(GCtx[X].Idx);
      Result := True;
    end;
    plFeed:
    begin
      if GCtx[X].Idx >= Length(GCtx[X].Feed.Items) then Exit;
      FillFile(FindData,
        GCtx[X].Feed.Items[GCtx[X].Idx].FileName,
        IfThenInt(GCtx[X].Feed.Items[GCtx[X].Idx].PubDateTime >
          GCtx[X].PrevLastFetch, 1, 0),
        GCtx[X].Feed.Items[GCtx[X].Idx].PubDateTime);
      LogDetail('Size[' + IntToStr(GCtx[X].Idx) + '] ' +
        String(GCtx[X].Feed.Items[GCtx[X].Idx].FileName) +
        ' pub=' + FloatToStr(GCtx[X].Feed.Items[GCtx[X].Idx].PubDateTime) +
        ' prev=' + FloatToStr(GCtx[X].PrevLastFetch) +
        ' newer=' + BoolToStr(
          GCtx[X].Feed.Items[GCtx[X].Idx].PubDateTime >
          GCtx[X].PrevLastFetch, True));
      Inc(GCtx[X].Idx);
      Result := True;
    end;
  end;
end;

procedure VfsFindClose(SearchHandle: THandle);
var X: Integer;
begin
  X := Integer(SearchHandle) - 1;
  if (X >= 0) and (X < MAX_CTX) then FreeCtx(X);
end;

function VfsGetFileContent(const Path: UnicodeString;
  out Content: AnsiString; out ErrMsg: UnicodeString): Boolean;
var
  PI: TPathInfo;
  Feed: TRssFeed;
  I: Integer;
begin
  Result := False;
  Content := '';
  ErrMsg := '';
  PI := VfsParsePath(Path);
  if (PI.Level <> plFile) or (PI.FileName = '') then
  begin ErrMsg := 'Not a file path'; Exit; end;
  Feed := Default(TRssFeed);
  if not FetchFeed(PI.FeedTitle, Feed, ErrMsg) then Exit;
  for I := 0 to Length(Feed.Items)-1 do
    if CompareText(String(Feed.Items[I].FileName), String(PI.FileName)) = 0 then
    begin
      Content := UTF8Encode(RenderItem(ConfigGetActiveTemplate, Feed.Items[I]));
      Result := True;
      Exit;
    end;
  ErrMsg := 'Not found: ' + PI.FileName;
end;

function VfsGetFeed(const Title: UnicodeString;
  out Feed: TRssFeed; out ErrMsg: UnicodeString): Boolean;
begin
  ErrMsg := '';
  Feed := Default(TRssFeed);
  Result := FetchFeed(Title, Feed, ErrMsg);
end;

procedure VfsClearCache;
begin
  EnterCriticalSection(GCacheLock);
  try GCache := nil;
  finally LeaveCriticalSection(GCacheLock); end;
end;

procedure VfsClearFeedCache(const Title: UnicodeString);
var I: Integer;
begin
  EnterCriticalSection(GCacheLock);
  try
    for I := 0 to Length(GCache)-1 do
      if GCache[I].Title = Title then
      begin GCache[I].CacheValid := False; Exit; end;
  finally
    LeaveCriticalSection(GCacheLock);
  end;
end;

finalization
  if GReady then
  begin
    DeleteCriticalSection(GCacheLock);
    DeleteCriticalSection(GCtxLock);
  end;

end.
