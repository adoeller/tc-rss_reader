# WFX RSS Reader Plugin für Total Commander

Ein WFX-Dateisystem-Plugin, das RSS-Feeds als virtuelles Dateisystem
in der Netzwerkumgebung von Total Commander darstellt.

## Features

- RSS 2.0 Feeds als Ordner in der Netzwerkumgebung
- Feed-Einträge als HTML-Dateien (per Template konfigurierbar)
- Konfigurationsdialog zum Verwalten der Feeds
- Feed-Test (Verbindungstest pro Feed)
- Cache mit 5-Minuten-Timeout
- Vollständig Unicode (64-bit)
- Kein LCL, reines Win32 API
- ANSI-Stubs für Kompatibilität

## Voraussetzungen

- [Lazarus IDE](https://www.lazarus-ide.org/) 2.2+ mit Free Pascal 3.2+
- Windows 64-bit
- Total Commander 9.0+ (64-bit)

## Bauen

### Mit Lazarus IDE
1. `wfx_rss.lpi` in Lazarus öffnen
2. Build-Modus **Release64** auswählen
3. Menü → Run → Build (Strg+F9)
4. Erzeugt: `wfx_rss.wfx64`

### Mit Kommandozeile (FPC direkt)
```batch
cd src
fpc -O2 -Xs -XX -CX -Px86_64 -Twin64 wfx_rss.lpr
```

## Installation in Total Commander

### Automatisch (empfohlen)
1. `wfx_rss.wfx64` + `pluginst.inf` + `Default.tmpl` + `wfx_rss.ini`
   in ein ZIP packen
2. ZIP in Total Commander öffnen → Plugin wird automatisch installiert

### Manuell
1. Plugin-Dateien in gewünschtes Verzeichnis kopieren
2. In TC: Konfigurieren → Einstellungen → Plugins → Dateisystem-Plugins
3. "Hinzufügen" → `wfx_rss.wfx64` auswählen

## Benutzung

1. In TC die **Netzwerkumgebung** öffnen (Laufwerksliste → \\)
2. **RSS Reader** auswählen
3. Die konfigurierten Feeds werden als Ordner angezeigt
4. In einen Feed-Ordner wechseln → Einträge als HTML-Dateien
5. Doppelklick → Eintrag im Browser öffnen
6. F5 → Eintrag als HTML-Datei kopieren

### Konfiguration
- **Properties** (Alt+Enter) auf dem Plugin → Konfigurationsdialog
- Feeds hinzufügen/entfernen
- Template-Datei ändern
- Cache manuell leeren

### Feeds verwalten
- **Konfigurationsdialog**: Feeds hinzufügen, entfernen, testen
- **Ordner erstellen** (F7): Neuen Feed per URL hinzufügen
- **Ordner löschen** (Del): Feed entfernen

## Dateien

```
wfx_rss.wfx64       Kompiliertes Plugin (64-bit)
wfx_rss.ini          Konfigurationsdatei
Default.tmpl         HTML-Template für Feed-Einträge
pluginst.inf         TC Auto-Installer
```

## Template-Platzhalter

| Platzhalter      | Inhalt                    |
|------------------|---------------------------|
| `<%title%>`      | Titel des Eintrags        |
| `<%link%>`       | URL des Eintrags          |
| `<%description%>`| Beschreibung/Inhalt       |
| `<%pubDate%>`    | Veröffentlichungsdatum    |
| `<%author%>`     | Autor                     |
| `<%category%>`   | Kategorie                 |
| `<%guid%>`       | Eindeutige ID             |
| `<%comments%>`   | Kommentar-URL             |
| `<%enclosure%>`  | Anhang (Medien-URL)       |
| `<%source%>`     | Quelle                    |

## Projektstruktur

```
src/
├── wfx_rss.lpr      Hauptbibliothek, WFX-Exports
├── fsplugin.pas      TC WFX SDK Typen
├── rss_types.pas     Gemeinsame Datentypen
├── rss_log.pas       Logging
├── rss_config.pas    INI-Konfiguration
├── rss_http.pas      HTTP via WinInet
├── rss_parser.pas    RSS XML Parser
├── rss_template.pas  HTML Template Engine
├── rss_vfs.pas       Virtuelles Dateisystem
└── rss_dialog.pas    Win32 Konfigurationsdialog
```

## Lizenz

Frei verwendbar. Kein Copyright beansprucht.
