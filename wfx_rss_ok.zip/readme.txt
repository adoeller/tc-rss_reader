RSS Reader.

Plugin to reading newsfeeds.

SETUP
As any wfx plugin, there is no difficult.

CONFIGURATION
In plugin's property window set proxy configuration, select template.
Create new folder with URL of feed. In folder's property window set 
period of update and encode.

To update feeds type in command line 'update'

HISTORY
[20 sep 2005]
Version 0.7 Release
* Remove bugs with showing some feeds

[18 sep 2005]
Version 0.7 Beta
+ Cyrillic encode
+ Set period update feeds
* Correct work with proxy


[11 sep 2005]
Version 0.65 Release
+ Support Socks
+ View date of publication

[21 aug 2005]
Version 0.6 Release
+ Proxy support
+ Background reload
* Fix wrong tag work

[11 aug 2005]
Version 0.4 Release

[7 aug 2005]
Version 0.1 Preview.
+ New plugin born!

+==============================================+
|  Michail Doronin (aka MiDoS) msd_0@mail.ru   |
|  Russian Federation, Altay State, Rubtsovsk  |
|  WebMoney R606303800883 Z944542031717        |
|  If you donate me, I will write more!        | 
+==============================================+